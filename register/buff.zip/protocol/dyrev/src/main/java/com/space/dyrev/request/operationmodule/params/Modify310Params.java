package com.space.dyrev.request.operationmodule.params;

import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.encrypt.PhoneNumberEncrypt;
import com.space.dyrev.request.commonparams.CommonParams;
import com.space.dyrev.util.formatutil.StringUtil;
import com.space.dyrev.util.httputil.CookieTool;

import java.util.HashMap;
import java.util.Map;

/**
 * @program: dyrev
 * @description: 310版本修改信息请求参数构造类
 * @author: Mr.Jia
 * @create: 2018-11-13 01:09
 **/
public class Modify310Params {

    private static final String HOST = "api.amemv.com";

    private static final String FUNC = "/aweme/v1/commit/user/?";


    /**
     * 构造url
     * @param dyUserEntity
     * @return
     */
    public static String constructUrl(DyUserEntity dyUserEntity) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();
        String url = "https://"+HOST+FUNC+"os_api="+CommonParams.OS_API+"&device_type="+deviceEntity.getDeviceType()+"&device_platform=android&ssmix=a&iid="+deviceEntity.getInstallId()+"&manifest_version_code=310&dpi="+deviceEntity.getDpi()+"&uuid="+deviceEntity.getUuid()+"&version_code=310&app_name=aweme&version_name=3.1.0&openudid="+deviceEntity.getOpenudid()+"&device_id="+deviceEntity.getDeviceId()+"&resolution="+deviceEntity.getResolution()+"&os_version="+CommonParams.OS_VERSION+"&language=zh&device_brand="+deviceEntity.getDeviceBrand()+"&ac=wifi&update_version_code=3102&aid=1128&channel=meizu&_rticket="+System.currentTimeMillis()+"&ts="+System.currentTimeMillis()/1000+"&js_sdk_version=1.2.2&as=a1iosdfgh&cp=androide1";

        return url;
    }

    /**
     * 构造header
     * @param dyUserEntity
     * @return
     */
    public static Map constructHeader(DyUserEntity dyUserEntity) {

        Map<String, String> header = new HashMap<String, String>();
        header.put("Host","api.amemv.com");
        header.put("Connection","keep-alive");
        header.put("Accept-Encoding","gzip");
        header.put("Content-Length","1000");
        header.put("Cookie", CookieTool.getCookieFromDevAndAcc(dyUserEntity.getDevice(), dyUserEntity));
        header.put("sdk-version","1");
        header.put("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
        //X-Tt-Token 我暂时没加
        header.put("X-Tt-Token","");
        header.put("X-SS-TC","0");
        header.put("User-Agent", CommonParams.getUserAgent(dyUserEntity.getDevice().getDeviceType()));


        return header;
    }

    /**
     * 构造body
     * @param dyUserEntity
     * @return
     */
    public static Map constructBody(DyUserEntity dyUserEntity,Map<String, String> info) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();

        Map<String, String> body = new HashMap<String, String>();
        body.put("uid",dyUserEntity.getUserId());
        body.put("os_api",CommonParams.OS_API);
        body.put("device_type",deviceEntity.getDeviceType());
        body.put("ssmix","a");
        body.put("manifest_version_code","310");
        body.put("dpi",deviceEntity.getDpi());
        body.put("uuid",deviceEntity.getUuid());
        body.put("app_name","aweme");
        body.put("version_name","3.1.0");
        body.put("retry_type","no_retry");
        body.put("ac","wifi");
        body.put("channel","meizu");
        body.put("update_version_code","3102");
        body.put("_rticket", String.valueOf(System.currentTimeMillis()));
        body.put("device_platform","android");
        body.put("iid",deviceEntity.getInstallId());
//        body.put("mix_mode","1");
        body.put("version_code","310");
        body.put("openudid",deviceEntity.getOpenudid());
        body.put("device_id",deviceEntity.getDeviceId());
        body.put("resolution",deviceEntity.getResolution());
        body.put("os_version",CommonParams.OS_VERSION);
        body.put("language","zh");
        body.put("device_brand",deviceEntity.getDeviceBrand());
        body.put("aid","1128");
        for(String key : info.keySet()){
            body.put(key.toString(),info.get(key).trim());
        }

        return body;
    }
}
