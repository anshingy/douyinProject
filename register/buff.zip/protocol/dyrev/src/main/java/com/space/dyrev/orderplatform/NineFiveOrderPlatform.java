package com.space.dyrev.orderplatform;

import com.mysql.cj.x.protobuf.Mysqlx;
import com.space.dyrev.commonentity.OrderEntity;
import com.space.dyrev.enumeration.OrderTypeEnum;
import com.space.dyrev.ordermodule.dao.OrderEntityRepository;
import com.space.dyrev.util.springutils.SpringUtil;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.Date;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * @program: protocol
 * @description: 95平台使用官方ai
 * @author: gaoxiang
 * @create: 2018-11-09 22:24
 **/
public class NineFiveOrderPlatform {

    public HashMap<OrderEnum,String> urltable;

    public String BusinessType;

    public OkHttpClient okHttpClient;

    public static OrderEntityRepository orderEntityRepository;

    public static NineFiveOrderPlatform thumbUpOrderController = new NineFiveOrderPlatform(NineFiveTable.thumbUpMap,"点赞");

    public static NineFiveOrderPlatform takePowerOrderController = new NineFiveOrderPlatform(NineFiveTable.takePowerMap,"关注");

    private NineFiveOrderPlatform (HashMap<OrderEnum,String> hashMap,String type){
        this.urltable = hashMap;
        this.BusinessType = type;
        okHttpClient = new OkHttpClient();
    }

    /**
     *
     * @param type 目前可选类型为点赞 关注
     * @return
     */
    public static NineFiveOrderPlatform getInstrance(String type) throws NullTypeException {
        if(type.equals("点赞")){
            return  thumbUpOrderController;
        }else if(type.equals("关注")){
            return takePowerOrderController;
        }else{
         throw new NullTypeException("tm的劳资跟你说有这个业务了吗，瞎搞什么");
        }
    }

    public ArrayList<OrderEntity> getAllNewOrders(){
        if(orderEntityRepository==null){
            orderEntityRepository = SpringUtil.getBean(OrderEntityRepository.class);
        }

        String powerUrl = urltable.get(OrderEnum.UnBeginOrder);
        JSONObject jsonObject =null;
        JSONArray jsonArray = null;
        ArrayList<OrderEntity> orderEntities = new ArrayList<>();
        OrderEntity orderEntity = null;
        Request request = new Request.Builder()
            .get()
            .url(powerUrl)
            .build();
        try {
            Response response = okHttpClient.newCall(request).execute();
            String result = new String(response.body().bytes());
            System.out.println(result);
            jsonObject = new JSONObject(result);
            //System.out.println(jsonObject.toString());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        int total = 0;
        try {
            total = jsonObject.getInt("total");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if(total ==0){
            return orderEntities;
        }else{
            try {
                boolean status = jsonObject.getBoolean("status");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            try {
                jsonArray = jsonObject.getJSONArray("rows");
                for(int i=0;i<jsonArray.length();i++){
                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                    orderEntity =new OrderEntity();
                    orderEntity.setOperationCount(jsonObject1.getInt("need_num_0"));
                    if(this.BusinessType.equals("点赞")){
                        orderEntity.setOrderTypeEnum(OrderTypeEnum.DYDZ100);
                    }else{
                        orderEntity.setOrderTypeEnum(OrderTypeEnum.DYGZ100);
                    }
                    orderEntity.setTime(new Date().getTime());
                    orderEntity.setStatus("1");
                    orderEntity.setVideoId(jsonObject1.getString("aa"));
                    orderEntity.setNineFiveId(jsonObject1.getInt("id"));
                    orderEntities.add(orderEntity);
                    orderEntityRepository.save(orderEntity);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return orderEntities;
    }

    public ArrayList<OrderEntity> getAllWorkingOrders(){
        if(orderEntityRepository==null){
            orderEntityRepository = SpringUtil.getBean(OrderEntityRepository.class);
        }
        String powerUrl = urltable.get(OrderEnum.WorkingOrder);
        JSONObject jsonObject =null;
        JSONArray jsonArray = null;
        ArrayList<OrderEntity> orderEntities = new ArrayList<>();
        OrderEntity orderEntity = null;
        Request request = new Request.Builder()
            .get()
            .url(powerUrl)
            .build();
        try {
            Response response = okHttpClient.newCall(request).execute();
            String result = new String(response.body().bytes());
            //System.out.println(result);
            jsonObject = new JSONObject(result);
            System.out.println();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        int total = 0;
        try {
            total = jsonObject.getInt("total");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if(total ==0){
            return orderEntities;
        }else{
            try {
                boolean status = jsonObject.getBoolean("status");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            try {
                jsonArray = jsonObject.getJSONArray("rows");
                for(int i=0;i<jsonArray.length();i++){
                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                    orderEntity =new OrderEntity();
                    orderEntity.setOperationCount(jsonObject1.getInt("need_num_0"));
                    orderEntity.setOrderCount(0);
                    orderEntity.setOrderNumber(0+"");
                    if(this.BusinessType.equals("点赞")){
                        orderEntity.setOrderTypeEnum(OrderTypeEnum.DYDZ100);
                    }else{
                        orderEntity.setOrderTypeEnum(OrderTypeEnum.DYGZ100);
                    }
                    orderEntity.setPrice(0);
                    orderEntity.setQq("0");
                    orderEntity.setStatus("1");
                    String hehe = jsonObject1.getString("aa");

                    orderEntity.setVideoId(hehe);
                    orderEntity.setNineFiveId(jsonObject1.getInt("id"));
                    orderEntity.setTime(new Date().getTime());
                    orderEntities.add(orderEntity);
                    orderEntityRepository.save(orderEntity);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return orderEntities;
    }

    public boolean getOrderFinished(OrderEntity orderEntity){
        if(orderEntity.getNineFiveId()<0){
            return false;
        }
        String finishUrl = urltable.get(OrderEnum.FinishOrder);
        String finalString = finishUrl.replace("#######",orderEntity.getNineFiveId()+"");
        JSONObject jsonObject =null;
        JSONArray jsonArray = null;
        Request request = new Request.Builder()
            .get()
            .url(finalString)
            .build();
        try {
            Response response = okHttpClient.newCall(request).execute();
            String string =new String(response.body().bytes());
            //System.out.println(string);
            jsonObject = new JSONObject(string);
            //System.out.println(jsonObject.toString()+" ");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            return jsonObject.getBoolean("status");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean changeOrderCount(OrderEntity orderEntity){
        if(orderEntity.getNineFiveId()<0){
            return false;
        }
        String kao = " http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=edit&goods_id=27022&order_state=jxz&order_id="+orderEntity.getNineFiveId()+"&now_num="+orderEntity.getOperationCount()+"&end_num=0&apikey="+NineFiveTable.thumbUpMap;
        Request request = new Request.Builder()
            .get()
            .url(kao)
            .build();
        try {
            Response response = okHttpClient.newCall(request).execute();
            String result = new String(response.body().bytes());
            System.out.println();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }
    public static void main(String[]args){
        try {
            NineFiveOrderPlatform nineFiveOrderPlatform = NineFiveOrderPlatform.getInstrance("点赞");
            OrderEntity orderEntity =new OrderEntity();
            orderEntity.setNineFiveId(10);
            System.out.println(nineFiveOrderPlatform.getOrderFinished(orderEntity));
        } catch (NullTypeException e) {
            e.printStackTrace();
        }

    }
}

