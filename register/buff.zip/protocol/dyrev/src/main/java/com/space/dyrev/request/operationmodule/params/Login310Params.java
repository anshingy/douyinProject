package com.space.dyrev.request.operationmodule.params;

import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.encrypt.PhoneNumberEncrypt;
import com.space.dyrev.request.commonparams.CommonParams;
import com.space.dyrev.util.formatutil.StringUtil;

import java.util.HashMap;
import java.util.Map;

/**
 *           .]]]]]]`.            .]]]]`           .]]]]].            .,]]]]]`        .]]]]`
 *         ,@@@@@@@@@@^    @@@@./@@@@@@@@@^    =@@@@@@@@@@@@.      ]@@@@@@@@@@@^   ,@@@@@@@@@@`
 *        .@@@@`    .[`    @@@@@@@[`..[@@@@@   =@/`    .\@@@@    ,@@@@@[.    ,[.  /@@@/.  .\@@@\
 *        =@@@\            @@@@/.       @@@@^            @@@@   ,@@@@/           /@@@^      =@@@^
 *         \@@@@@]`        @@@@.        =@@@@        ...]@@@@   =@@@@           .@@@@]]]]]]]]@@@@
 *          ,\@@@@@@@]     @@@@.        .@@@@   ,@@@@@@@@@@@@   @@@@^           =@@@@@@@@@@@@@@@@
 *              ,\@@@@@`   @@@@.        =@@@@ ,@@@@/.    @@@@   =@@@@           .@@@@
 *                 =@@@@   @@@@.        /@@@^ @@@@.      @@@@   ,@@@@^           \@@@\
 *        =].      =@@@/   @@@@@]     ./@@@/  @@@@\    ,/@@@@`   ,@@@@@`      ,`  \@@@@`       .`
 *        =@@@@@@@@@@@/    @@@@@@@@@@@@@@@`   .@@@@@@@@@@/@@@@@^  .\@@@@@@@@@@@^   ,@@@@@@@@@@@@@
 *         ,[\@@@@@[`      @@@@..[\@@@@[.       .[@@@@[.  ,\@@@[     ,[@@@@@/[`.      ,[@@@@@/[`.
 *                         @@@@.
 *                         @@@@.
 *                         @@@@.
 *                                                                                             @ClassName Login310Params
 *                                                                                             @Author: space
 *                                                                                             @Description TODO 
 *                                                                                             @Date: 2018/10/11 23:29
 **/
public class Login310Params {
    // HOST
    private static final String HOST = "is.snssdk.com";

    // 请求头方法
    private static final String FUNC = "/passport/mobile/login/?";

    /**
     * 构造url请求头
     * @param dyUserEntity 帐号实体类
     * @return url
     */
    public static String constructUrl(DyUserEntity dyUserEntity) {

//        StringBuffer url = new StringBuffer("https://");
//        url.append(HOST);
//        url.append(FUNC);
//        // 公共部分
//        url.append(CommonUrlPart.deviceUrl(dyUserEntity.getDevice()));
//        url.append("&as=" + CommonParams.AS);
//        url.append("&cp=" + CommonParams.CP);
        DeviceEntity deviceEntity = dyUserEntity.getDevice();
        String url = "https://"+HOST + FUNC+"os_api=23&device_type="+deviceEntity.getDeviceType()+"&device_platform=android&ssmix=a" +
                "&iid="+deviceEntity.getInstallId()+"&manifest_version_code=310&dpi=320&uuid="+deviceEntity.getUuid()+"&version_code=310" +
                "&app_name=aweme&version_name=3.1.0&openudid="+deviceEntity.getOpenudid()+"&device_id="+deviceEntity.getDeviceId()+
                "&resolution=720*1280&os_version=6.0.1&language=zh&device_brand=Xiaomi&ac=mobile" +
                "&update_version_code=3102&aid=1128&channel=meizu" +
                "&_rticket="+System.currentTimeMillis()+"&ts="+System.currentTimeMillis()/1000+"&js_sdk_version=1.2.2&as=a1iosdfgh&cp=androide1";
        return url;
    }

    /**
     * 构造header
     * @param dyUserEntity
     * @return
     */
    public static Map constructHeader(DyUserEntity dyUserEntity) {

        Map<String, String> header = new HashMap<>();
        header.put("Accept-Encoding","gzip");
        header.put("Host",HOST);
        header.put("Connection","keep-alive");
        header.put("Content-Length","500");
        header.put("Cookie", "install_id=" + dyUserEntity.getDevice().getInstallId() +"; qh[360]=1");

        header.put("X-SS-REQ-TICKET", String.valueOf(System.currentTimeMillis()));
        header.put("sdk-version","1");
//        header.put("X-Tt-Token","");
        header.put("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
        header.put("X-SS-TC","0");
        header.put("User-Agent","com.ss.android.ugc.aweme/310 (Linux; U; Android 6.0.1; zh_CN; "+dyUserEntity.getDevice().getDeviceType()+"; Build/MMB29M; Cronet/58.0.2991.0)");

        return header;
    }


    /**
     * 构造body
     * @param dyUserEntity
     * @return
     */
    public static Map constructBody(DyUserEntity dyUserEntity, String captcha) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();

        Map<String, String> body = new HashMap<>();
        body.put("os_api", CommonParams.OS_API);
        body.put("device_type",deviceEntity.getDeviceType());
        body.put("ssmix",CommonParams.SSMIX);
        body.put("manifest_version_code","310");
        body.put("dpi",deviceEntity.getDpi());
        body.put("uuid",deviceEntity.getUuid());
        body.put("app_name",CommonParams.APP_NAME);
        body.put("version_name","3.1.0");
        body.put("retry_type","no_retry");
        body.put("ac",deviceEntity.getAccess());
        body.put("channel","meizu");
        body.put("update_version_code", "3102");
        body.put("_rticket", String.valueOf(System.currentTimeMillis()));
        body.put("device_platform",CommonParams.DEVICE_PLATFORM);
        body.put("password","647661343736313033");
        body.put("iid",deviceEntity.getInstallId());
        body.put("mix_mode","1");
        body.put("mobile", PhoneNumberEncrypt.codeEncode(dyUserEntity.getArea() + dyUserEntity.getAccount()));
        body.put("version_code","310");
        if (StringUtil.isNotEmpty(captcha)) {
            body.put("captcha", captcha);
        }
        body.put("openudid",deviceEntity.getOpenudid());
        body.put("device_id",deviceEntity.getDeviceId());
        body.put("resolution",deviceEntity.getResolution());
        body.put("os_version",CommonParams.OS_VERSION);
        body.put("language",CommonParams.LANGUAGE);
        body.put("device_brand",deviceEntity.getDeviceBrand());
        body.put("aid",CommonParams.AID);


        return body;
    }
}
