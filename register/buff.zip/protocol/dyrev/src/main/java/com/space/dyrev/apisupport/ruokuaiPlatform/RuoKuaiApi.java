package com.space.dyrev.apisupport.ruokuaiPlatform;

import com.space.dyrev.paintplatform.PictureBuilder;
import org.json.JSONException;
import org.json.JSONObject;
import com.csvreader.CsvWriter;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * @program: protocol
 * @description: 若快平台封装api
 * @author: gaoxiang
 * @create: 2018-11-18 15:35
 **/
public class RuoKuaiApi {
    //对此处api进行补全
    public static String userName = "gaoxiang15125";
    public static String password = "18805156570";
    public static String softKey = "209a3f172e5a4e76be5c1359247fa655";
    public static String softId = "116482";
    public static String typeID = "6903";
    public static String timeOut = "90";
    public static PictureBuilder mainPanel =null ;

    /**
     * 解析1104验证码错误，返回验证码解析结果
     * @param urlOne 两个图片的链接
     * @param urlTwo
     * @return
     */
    public static RukuaiPo getCodeResultFrom1104(String urlOne,String urlTwo){

        if(mainPanel ==null){
            mainPanel = PictureBuilder.getInstance();
        }
        String result =null;
        String[] resultBaseString = null;
        synchronized (mainPanel) {
            BufferedImage bi = new BufferedImage(268, 186, BufferedImage.TYPE_INT_BGR);
            bi = mainPanel.writeImage(bi, urlOne, urlTwo);
            mainPanel.writeImage(bi);
            String fileUrl = mainPanel.getClass().getClassLoader().getResource(PictureBuilder.localImageUrl).getPath();
            System.out.println(fileUrl);
            result = RuoKuai.createByPost(userName, password, typeID, timeOut, softId, softKey, fileUrl);
            System.out.println(result);
        }
        String id = null;
        try {
            JSONObject jsonObject3 = new JSONObject(result);
            if(jsonObject3.has("Result")){
                String string = jsonObject3.getString("Result");
                resultBaseString = string.split(".");
                id = jsonObject3.getString("Id");
            }else{
                System.out.println("##########1104验证码解析错误哦");
                return  null;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ArrayList<HashMap<String, String>> posResult = new ArrayList<>();
        for(int i =0;i<resultBaseString.length;i++){
            HashMap<String,String> base = new HashMap<>();
            String[] posPlaces = resultBaseString[i].split(",");
            String x = posPlaces[0];
            String y = posPlaces[1];
            if(x.equals("0")||y.equals("0")){
                base.put(x,y);
                posResult.add(base);
            }else {
                base.put(String.valueOf(Double.parseDouble(x)- PictureBuilder.picTwo_y),String.valueOf(Double.parseDouble(y)-PictureBuilder.picTwo_y));
                posResult.add(base);
            }
        }
        RukuaiPo rukuaiPo = new RukuaiPo();
        rukuaiPo.setPosPlace(posResult);
        rukuaiPo.setPicID(id);
        return rukuaiPo;
    }

    /**
     * 对指定图片解析结果报错，告诉平台本验证码识别失败
     * @param id RukuaiPo中标识图片的ID
     */
    public static void takeErrorOnCode(String id ){
        RuoKuai.report(userName,password,softId,softKey,id);
    }
    public static void main(String[]args){
        RuoKuaiApi.getCodeResultFrom1104("http://sf3-dycdn-tos.pstatp.com/obj/security-captcha/text_154d481eafb2f549dad53087fc50c28b209bfe5c_1_1.jpg","http://sf3-dycdn-tos.pstatp.com/obj/security-captcha/text_154d481eafb2f549dad53087fc50c28b209bfe5c_2_1.jpg");

    }
}

//        JSONObject jsonObject = null;
//        JSONObject jsonObject1 = null;
//        JSONObject jsonObject2 = null;
//        String urlOne = null;
//        String urlTwo = null;
//        try {
//            jsonObject = new JSONObject(errorJson);
//            jsonObject1 = jsonObject.getJSONObject("data");
//            jsonObject2 = jsonObject1.getJSONObject("question");
//            urlOne = jsonObject2.getString("url1");
//            urlTwo = jsonObject2.getString("url2");
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }