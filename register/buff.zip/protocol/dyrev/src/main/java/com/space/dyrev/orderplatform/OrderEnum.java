package com.space.dyrev.orderplatform;

/**
 * @program: protocol
 * @description: 订单请求类型枚举类
 * @author: gaoxiang
 * @create: 2018-11-09 22:35
 **/
public enum OrderEnum {

    Apikey(),QueueOrder(),UnBeginOrder(),WorkingOrder(),CancelOrder(),ChangePasswordOrder(),
    WaitMoneyOrder(),WaitforUpOrder(),UpdateOrder(),FinishOrder(),DeleteOrder();

    //同一个站点对调用api有时间间隔限制,暂定：下载订单接口每业务每1分钟限2次,操作订单接口整站每10分钟最高600次。
}
