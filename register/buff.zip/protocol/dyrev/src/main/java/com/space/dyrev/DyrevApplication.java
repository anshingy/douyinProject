package com.space.dyrev;

import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.commonentity.OrderEntity;
import com.space.dyrev.dao.DyUserRepository;
import com.space.dyrev.enumeration.OkhttpType;
import com.space.dyrev.ordermodule.dao.OrderEntityRepository;
import com.space.dyrev.orderplatform.OrderEnum;
import com.space.dyrev.request.operationmodule.service.OperationService;
import com.space.dyrev.request.operationmodule.service.impl.OperationServiceImpl;
import com.space.dyrev.thread.config.ExecutorConfig;
import com.space.dyrev.thread.service.UserThreadService;
import com.space.dyrev.thread.service.impl.MessionThread;
import com.space.dyrev.util.httputil.OkHttpTool;
import com.space.dyrev.util.springutils.SpringUtil;
import okhttp3.OkHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Import;

import java.util.ArrayList;

@Import(SpringUtil.class)
@SpringBootApplication
public class DyrevApplication {

    protected static final Logger logger = LoggerFactory.getLogger(DyrevApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(DyrevApplication.class, args);

//        RegisterProcess registerProcess = (RegisterProcess) SpringUtil.getApplicationContext().getBean("registerProcess");
//
//        OperationService digg = SpringUtil.getBean(OperationService.class);
//
//        AppLogService applog = SpringUtil.getBean(AppLogService.class);
//
//        OkHttpClient okHttpClient = OkHttpTool.getOkhttpClient(OkhttpType.PROXY);


        // 注册全过程
//        registerProcess.registerUserProcess(okHttpClient);

        // 测试登陆帐号
//        PhoneEntity phoneEntity = new PhoneEntity(PhoneArea.CHINA, "13532021111");
//        phoneEntity.setCode("2797");
//        registerProcess.sendCode(okHttpClient, phoneEntity);
//        registerProcess.smslogin(okHttpClient, phoneEntity);


        // 登陆
        //registerProcess.testPassportMobileLogin(okHttpClient, 112982, "");



        // 点赞
//        digg.digg(okHttpClient, 112984, "6609453344350014728");

        //AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ExecutorConfig.class);
        logger.info("------------服务注册成功------------");
        MessionThread messionThread = MessionThread.getInstrance();
        messionThread.diggAndthumbUp();
        logger.info("------------订单插入成功------------");
        int cnm = 55;
//        OperationServiceImpl operationService = SpringUtil.getBean(OperationServiceImpl.class);
//        DyUserRepository dyUserRepository = SpringUtil.getBean(DyUserRepository.class);
//        DyUserEntity dyUserEntity = dyUserRepository.findById(112994);
//        OrderEntityRepository orderEntityRepository = SpringUtil.getBean(OrderEntityRepository.class);
//        OrderEntity orderEntity;
//        OkHttpClient okHttpClient = null;
//        while (cnm>0){
//            okHttpClient = OkHttpTool.getOkhttpClient(OkhttpType.PROXY);
//            ArrayList<String> strings = operationService.feed(okHttpClient,dyUserEntity,dyUserEntity.getDevice());
//            for(String string:strings){
//                orderEntity = new OrderEntity();
//                orderEntity.setOperationCount(100);
//                orderEntity.setTime("2018/11/12");
//                orderEntity.setStatus("1");
//                orderEntity.setVideoId(string);
//                orderEntityRepository.save(orderEntity);
//            }
//            try {
//                Thread.sleep(10000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
    }
}
