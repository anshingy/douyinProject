package com.space.dyrev.request.operationmodule.params;

import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.request.commonparams.CommonParams;
import com.space.dyrev.util.httputil.CookieTool;

import java.util.HashMap;
import java.util.Map;

/**
 * @program: dyrev
 * @description: 310版本关注请求参数构造
 * @author: Mr.Jia
 * @create: 2018-11-13 00:50
 **/
public class Follow310Params {

    private static final String HOST = "api.amemv.com";

    private static final String FUNC = "/aweme/v1/commit/follow/user/?";

    /**
     * 构造url
     * @param dyUserEntity
     * @param userId
     * @return
     */
    public static String constructUrl(DyUserEntity dyUserEntity, String userId) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();
        String url = "https://"+HOST+FUNC+"user_id="+userId+"&type=1&retry_type=no_retry&iid="+deviceEntity.getInstallId()+"&device_id="+deviceEntity.getDeviceId()+"&ac=wifi&channel=meizu&aid=1128&app_name=aweme&version_code=310&version_name=3.1.0&device_platform=android&ssmix=a&device_type="+deviceEntity.getDeviceType()+"&device_brand="+deviceEntity.getDeviceBrand()+"&language=zh&os_api="+ CommonParams.OS_API+"&os_version="+CommonParams.OS_VERSION+"&uuid="+deviceEntity.getUuid()+"&openudid="+deviceEntity.getOpenudid()+"&manifest_version_code=310&resolution="+deviceEntity.getResolution()+"&dpi="+deviceEntity.getDpi()+"&update_version_code=3102&_rticket="+System.currentTimeMillis()+"&ts="+System.currentTimeMillis()/1000+"&js_sdk_version=1.2.2&as="+CommonParams.AS+"&cp="+CommonParams.CP;

        return url;
    }

    /**
     * 构造header
     * @param dyUserEntity
     * @return
     */
    public static Map constructHeader(DyUserEntity dyUserEntity) {

        Map<String, String> header = new HashMap<String, String>();
        header.put("Host","api.amemv.com");
        header.put("Connection","keep-alive");
        header.put("Accept-Encoding","gzip");
        header.put("Cookie", CookieTool.getCookieFromDevAndAcc(dyUserEntity.getDevice(), dyUserEntity));
        header.put("sdk-version","1");
        //X-Tt-Token 我暂时没加
        header.put("X-Tt-Token","");
        header.put("X-SS-TC","0");
        header.put("User-Agent",CommonParams.getUserAgent(dyUserEntity.getDevice().getDeviceType()));

        return header;
    }
}
