package com.space.dyrev.orderplatform;

/**
 * @program: protocol
 * @description:
 * @author: gaoxiang
 * @create: 2018-11-15 12:37
 **/
public class NullTypeException extends Exception{

    public NullTypeException(String message){
        super(message);
    }
}
