package com.space.dyrev.enumeration;

public enum OkhttpType {
    PROXY,
    NO_PROXY;
}
