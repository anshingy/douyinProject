package com.space.dyrev.oldtype.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.dao.DeviceRepository;
import com.space.dyrev.dao.DyUserRepository;
import com.space.dyrev.oldtype.dao.TempDeviceRepository;
import com.space.dyrev.oldtype.dao.TempDyUserRepository;
import com.space.dyrev.oldtype.entity.TempDevice;
import com.space.dyrev.oldtype.entity.TempUser;
import com.space.dyrev.oldtype.service.TransService;
import com.space.dyrev.request.commonparams.CommonParams;
import com.space.dyrev.util.deviceinfoutil.CreateDevInfoUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;


import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 *           .]]]]]]`.            .]]]]`           .]]]]].            .,]]]]]`        .]]]]`
 *         ,@@@@@@@@@@^    @@@@./@@@@@@@@@^    =@@@@@@@@@@@@.      ]@@@@@@@@@@@^   ,@@@@@@@@@@`
 *        .@@@@`    .[`    @@@@@@@[`..[@@@@@   =@/`    .\@@@@    ,@@@@@[.    ,[.  /@@@/.  .\@@@\
 *        =@@@\            @@@@/.       @@@@^            @@@@   ,@@@@/           /@@@^      =@@@^
 *         \@@@@@]`        @@@@.        =@@@@        ...]@@@@   =@@@@           .@@@@]]]]]]]]@@@@
 *          ,\@@@@@@@]     @@@@.        .@@@@   ,@@@@@@@@@@@@   @@@@^           =@@@@@@@@@@@@@@@@
 *              ,\@@@@@`   @@@@.        =@@@@ ,@@@@/.    @@@@   =@@@@           .@@@@
 *                 =@@@@   @@@@.        /@@@^ @@@@.      @@@@   ,@@@@^           \@@@\
 *        =].      =@@@/   @@@@@]     ./@@@/  @@@@\    ,/@@@@`   ,@@@@@`      ,`  \@@@@`       .`
 *        =@@@@@@@@@@@/    @@@@@@@@@@@@@@@`   .@@@@@@@@@@/@@@@@^  .\@@@@@@@@@@@^   ,@@@@@@@@@@@@@
 *         ,[\@@@@@[`      @@@@..[\@@@@[.       .[@@@@[.  ,\@@@[     ,[@@@@@/[`.      ,[@@@@@/[`.
 *                         @@@@.
 *                         @@@@.
 *                         @@@@.
 *                                                                                             @ClassName TransServiceImpl
 *                                                                                             @Author: space
 *                                                                                             @Description TODO 
 *                                                                                             @Date: 2018/10/11 23:29
 **/
@Service("transService")
public class TransServiceImpl implements TransService {

    private static final Logger logger = LoggerFactory.getLogger(TransServiceImpl.class);

    @Resource
    DeviceRepository deviceRepository;

    @Resource
    DyUserRepository dyUserRepository;

    @Resource
    TempDeviceRepository tempDeviceRepository;

    @Resource
    TempDyUserRepository tempDyUserRepository;


    @Override
//    @Async("asyncServiceExecutor")
    public Page<TempUser> getPage(int page, int size) {
        logger.info(" ----- 正在读取读出数据: 第 {} 页，总共 {} 条 -----", page, size);
        ArrayList<TempUser> tempUsers = tempDyUserRepository.getUserByLike(71146);
        System.out.println("###############开始不全###################");
        for(int i =0;i<tempUsers.size();i++){
            saveOne(tempUsers.get(i));
        }
        System.out.println("补全完毕，嘛 b劳资再也不管结果了");
        return null;
    }


    @Override
    @Async("asyncServiceExecutor")
    public void saveOne(TempUser tempUser) {
        DeviceEntity deviceEntity = new DeviceEntity();
        DyUserEntity dyUserEntity = new DyUserEntity();

        TempDevice tempDevice = tempDeviceRepository.findById(Integer.valueOf(tempUser.getSimulationID())).get();

        deviceEntity.setDeviceId(tempDevice.getDeviceId());
        deviceEntity.setAccess(CreateDevInfoUtil.createAc());
        deviceEntity.setCarries(CreateDevInfoUtil.createCarries());
        deviceEntity.setChannel(CommonParams.CHANNEL);
        deviceEntity.setDeviceType(tempDevice.getDevice_type());
        deviceEntity.setSimICCid(CreateDevInfoUtil.createSimICCid());
        deviceEntity.setTimeFirstSendInstallApp(String.valueOf(System.currentTimeMillis()));
        deviceEntity.setBuildSerial(CommonParams.BUILD_SERIAL);
        deviceEntity.setClientudid(CreateDevInfoUtil.createClientUdid());
        deviceEntity.setDeviceBrand(tempDevice.getDevice_brand());
        deviceEntity.setDpi(CreateDevInfoUtil.createDpi());
        deviceEntity.setImsi(CreateDevInfoUtil.createIMSI());
        deviceEntity.setInstallId(tempDevice.getIid());
        deviceEntity.setMc(CreateDevInfoUtil.createMac());
        deviceEntity.setOpenudid(tempDevice.getOpenudid());
        deviceEntity.setResolution(CreateDevInfoUtil.createResolution());
        deviceEntity.setUuid(tempDevice.getUuid());
        deviceEntity.setAdid(tempDevice.getOpenudid());
        deviceEntity.setDevicePlatform(CommonParams.DEVICE_PLATFORM);

        DeviceEntity save = deviceRepository.save(deviceEntity);
        dyUserEntity.setDevice(save);
        dyUserEntity.setAccount(tempUser.getPhoneNum());
        dyUserEntity.setArea(tempUser.getPhoneArea());
        dyUserEntity.setUserId(tempUser.getUid());
        dyUserEntity.setEventId(tempUser.getEvent_id());
        dyUserEntity.setPwd(tempUser.getPassword());

        DyUserEntity save1 = dyUserRepository.save(dyUserEntity);


        logger.info("------------ 存入前原id为{} ------------ -> ----- 存入后id为 {} ----- ", tempUser.getId(),save1.getId());

    }


}
