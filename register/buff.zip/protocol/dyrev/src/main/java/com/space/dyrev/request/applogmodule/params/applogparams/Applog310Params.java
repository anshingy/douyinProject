package com.space.dyrev.request.applogmodule.params.applogparams;

import com.alibaba.fastjson.JSONObject;
import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.request.commonparams.CommonParams;
import com.space.dyrev.util.httputil.CookieTool;

import java.util.HashMap;
import java.util.Map;

/**
 * @program: dyrev
 * @description: 310版本的applog
 * @author: Mr.Jia
 * @create: 2018-11-10 22:26
 **/
public class Applog310Params {

    // HOST
    private static final String HOST = "log.snssdk.com";

    // 请求头方法
    private static final String FUNC = "/service/2/app_log/?";

    public static String constructUrl(DyUserEntity dyUserEntity) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();
        String url = "http://"+HOST+FUNC+"iid="+deviceEntity.getInstallId()+"&device_id="+deviceEntity.getDeviceId()+"&ac=wifi&channel=meizu&aid=1128&app_name=aweme&version_code=310&version_name=3.1.0&device_platform=android&ssmix=a&device_type="+deviceEntity.getDeviceType()+"&device_brand="+deviceEntity.getDeviceBrand()+"&language=zh&os_api=25&os_version=7.1.2&uuid="+deviceEntity.getUuid()+"&openudid="+deviceEntity.getOpenudid()+"&manifest_version_code=310&resolution="+deviceEntity.getResolution()+"&dpi="+deviceEntity.getDpi()+"&update_version_code=3102&_rticket="+System.currentTimeMillis()+"&tt_data=a";

        return url.toString();
    }

    /**
     * 构造header
     * @param dyUserEntity
     * @return
     */
    public static Map constructHeader(DyUserEntity dyUserEntity) {

        Map<String, String> header = new HashMap<>();
        header.put("Accept-Encoding", "gzip");
        header.put("Host", HOST);
        header.put("Connection", "Keep-Alive");
        header.put("Content-Length", "1500");
        header.put("X-SS-REQ-TICKET", String.valueOf(System.currentTimeMillis()));
        header.put("X-Tt-Token","");
        header.put("sdk-version","1");
        header.put("X-SS-TC","0");
        header.put("X-SS-RS","0");
        header.put("Content-Type", "application/octet-stream;tt-data=a");
        header.put("Cookie", CookieTool.getCookieFromDevAndAcc(dyUserEntity.getDevice(), dyUserEntity));
        header.put("User-Agent",CommonParams.getUserAgent(dyUserEntity.getDevice().getDeviceType()));
        return header;
    }

}
