package com.space.dyrev.request.iosrequest.deviceregistermodule.params.deviceregisterparams;

import com.alibaba.fastjson.JSONObject;
import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.IosDeviceEntity;
import com.space.dyrev.request.commonparams.CommonParams;
import com.space.dyrev.request.iosrequest.ioscommonparams.IOSCommonV310Params;

/**
 *           .]]]]]]`.            .]]]]`           .]]]]].            .,]]]]]`        .]]]]`
 *         ,@@@@@@@@@@^    @@@@./@@@@@@@@@^    =@@@@@@@@@@@@.      ]@@@@@@@@@@@^   ,@@@@@@@@@@`
 *        .@@@@`    .[`    @@@@@@@[`..[@@@@@   =@/`    .\@@@@    ,@@@@@[.    ,[.  /@@@/.  .\@@@\
 *        =@@@\            @@@@/.       @@@@^            @@@@   ,@@@@/           /@@@^      =@@@^
 *         \@@@@@]`        @@@@.        =@@@@        ...]@@@@   =@@@@           .@@@@]]]]]]]]@@@@
 *          ,\@@@@@@@]     @@@@.        .@@@@   ,@@@@@@@@@@@@   @@@@^           =@@@@@@@@@@@@@@@@
 *              ,\@@@@@`   @@@@.        =@@@@ ,@@@@/.    @@@@   =@@@@           .@@@@
 *                 =@@@@   @@@@.        /@@@^ @@@@.      @@@@   ,@@@@^           \@@@\
 *        =].      =@@@/   @@@@@]     ./@@@/  @@@@\    ,/@@@@`   ,@@@@@`      ,`  \@@@@`       .`
 *        =@@@@@@@@@@@/    @@@@@@@@@@@@@@@`   .@@@@@@@@@@/@@@@@^  .\@@@@@@@@@@@^   ,@@@@@@@@@@@@@
 *         ,[\@@@@@[`      @@@@..[\@@@@[.       .[@@@@[.  ,\@@@[     ,[@@@@@/[`.      ,[@@@@@/[`.
 *                         @@@@.
 *                         @@@@.
 *                         @@@@.
 *                                                                                             @ClassName IosDeviceRegisterV310Params
 *                                                                                             @Author: space
 *                                                                                             @Description TODO 
 *                                                                                             @Date: 2018/10/11 23:29
 **/
//https://log.snssdk.com/service/2/device_register/?tt_data=a&ac=4G&device_id=55257582463&os_api=18&app_name=aweme&channel=App%20Store&idfa=7B78EA53-7B79-40FC-B507-0A166E30214C&device_platform=iphone&build_number=31006&vid=AE298654-FFB2-4221-8274-02692C0DBC11&openudid=1944cda2516eb4c0d68fe7590860072b7dbb8e26&device_type=iPhone10,3&app_version=3.1.0&version_code=3.1.0&os_version=12.0.1&screen_width=1125&aid=1128&pass-region=1 HTTP/1.1
public class IosDeviceRegisterV310Params {

    private static String HOST = "log.snssdk.com";

    private static String FUNC = "/service/2/device_register/?";

    public static String constructUrl(IosDeviceEntity device) {
        StringBuffer sb = new StringBuffer("https://" + HOST + FUNC);
        sb.append("tt_data=a");
        sb.append("&ac=" + device.getAc());
//        sb.append("&device_id=" + device.getdId());
        sb.append("&os_api=" + "18");
        sb.append("&app_name=" + IOSCommonV310Params.APP_NAME);
        sb.append("&channel=" + device.getChannel());
        sb.append("&idfa=" + device.getIdfa());
        sb.append("&build_number=" + IOSCommonV310Params.BUILD_NUMBER);
        sb.append("&vid=" + device.getVid());
        sb.append("&openudid="+device.getOpenudid());
        sb.append("&device_type=" + device.getDeviceType());
        sb.append("&app_version=" + IOSCommonV310Params.APP_VERSION);
        sb.append("&version_code=" + IOSCommonV310Params.VERSION_CODE);
        sb.append("&os_version=" + device.getOsVersion());
        sb.append("&screen_width=" + device.getScreenWidth());
        sb.append("&aid=" + IOSCommonV310Params.AID);
        sb.append("&pass-region=" + IOSCommonV310Params.PASS_REGION);
        return sb.toString();
    }

    /**
     * 构造json形式的body
     * @param deviceEntity
     * @return
     */
    public static JSONObject constructBody(IosDeviceEntity deviceEntity) {

        JSONObject header = new JSONObject();
        header.put("sdk_version", 1132);
        header.put("language","zh");
        header.put("user_agent","Aweme 3.1.0 rv:31006 (iPhone; "+deviceEntity.getOsVersion()+"; zh-Hans_HK)");
        header.put("app_name",IOSCommonV310Params.APP_NAME);
        header.put("app_version",IOSCommonV310Params.APP_VERSION);
        header.put("vendor_id",deviceEntity.getVid());
        header.put("is_upgrade_user","");
        header.put("region","CN");
        header.put("channel", deviceEntity.getChannel());
        header.put("mcc_mnc",deviceEntity.getMccMnc());
        header.put("tz_offset", 28800);
        header.put("app_region","CN");
        header.put("resolution",deviceEntity.getResolution());
        header.put("aid",IOSCommonV310Params.AID);
        header.put("os","iOS");
        header.put("","");

        JSONObject custom = new JSONObject();
//        custom




        return null;
    }

    /**
     * 构造header
     * @param deviceEntity
     * @return
     */
    public static JSONObject constructHeader(IosDeviceEntity deviceEntity) {
        return null;
    }

    public static void main(String[] args) {
        IosDeviceEntity deviceEntity = IosDeviceEntity.createIosDevice();
        System.out.println(constructUrl(deviceEntity));
    }
}
