package com.space.dyrev.request.accountregistermodule.service;

import com.alibaba.fastjson.JSONObject;
import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.commonentity.PhoneEntity;
import com.space.dyrev.enumeration.OkhttpType;
import okhttp3.OkHttpClient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *           .]]]]]]`.            .]]]]`           .]]]]].            .,]]]]]`        .]]]]`
 *         ,@@@@@@@@@@^    @@@@./@@@@@@@@@^    =@@@@@@@@@@@@.      ]@@@@@@@@@@@^   ,@@@@@@@@@@`
 *        .@@@@`    .[`    @@@@@@@[`..[@@@@@   =@/`    .\@@@@    ,@@@@@[.    ,[.  /@@@/.  .\@@@\
 *        =@@@\            @@@@/.       @@@@^            @@@@   ,@@@@/           /@@@^      =@@@^
 *         \@@@@@]`        @@@@.        =@@@@        ...]@@@@   =@@@@           .@@@@]]]]]]]]@@@@
 *          ,\@@@@@@@]     @@@@.        .@@@@   ,@@@@@@@@@@@@   @@@@^           =@@@@@@@@@@@@@@@@
 *              ,\@@@@@`   @@@@.        =@@@@ ,@@@@/.    @@@@   =@@@@           .@@@@
 *                 =@@@@   @@@@.        /@@@^ @@@@.      @@@@   ,@@@@^           \@@@\
 *        =].      =@@@/   @@@@@]     ./@@@/  @@@@\    ,/@@@@`   ,@@@@@`      ,`  \@@@@`       .`
 *        =@@@@@@@@@@@/    @@@@@@@@@@@@@@@`   .@@@@@@@@@@/@@@@@^  .\@@@@@@@@@@@^   ,@@@@@@@@@@@@@
 *         ,[\@@@@@[`      @@@@..[\@@@@[.       .[@@@@[.  ,\@@@[     ,[@@@@@/[`.      ,[@@@@@/[`.
 *                         @@@@.
 *                         @@@@.
 *                         @@@@.
 *
 *        @Author: space
 *        @Date: 2018/10/22 14:01
 *        @Description: 注册帐号的zservice
 *
 **/
public interface AccountRegisterService {

    /**
     * https://is.snssdk.com/passport/mobile/send_code/v1
     * 请求验证码
     * @param okHttpClient
     * @param phoneEntity
     * @param deviceEntity
     * @return
     */
    boolean sendCodeV270(OkHttpClient okHttpClient, PhoneEntity phoneEntity, DeviceEntity deviceEntity);

    /**
     * https://is.snssdk.com/passport/mobile/sms_login
     * 短信登陆
     * @param okHttpClient
     * @param phoneEntity
     * @param deviceEntity
     * @return
     */
    DyUserEntity smsLogin(OkHttpClient okHttpClient, PhoneEntity phoneEntity, DeviceEntity deviceEntity);

    DyUserEntity registerV176(OkHttpClient okHttpClient, PhoneEntity phoneEntity, DeviceEntity deviceEntity);

    /**
     * 310版本的发送验证吗
     * @param okHttpClient
     * @param phoneEntity
     * @param deviceEntity
     * @return
     */
    boolean sendCode310(OkHttpClient okHttpClient, PhoneEntity phoneEntity, DeviceEntity deviceEntity);

    /**
     * 短信登陆
     * @param okHttpClient
     * @param phoneEntity
     * @param deviceEntity
     * @return
     */
    DyUserEntity smsLogin310(OkHttpClient okHttpClient, PhoneEntity phoneEntity, DeviceEntity deviceEntity);

    /**
     * 是否已设置密码的请求，修改密码时候发送
     * @param okHttpClient
     * @param dyUserEntity
     */
    void whetherHasSet(OkHttpClient okHttpClient, DyUserEntity dyUserEntity);

    /**
     * 修改密码时候检查密码的请求
     * @param okHttpClient
     */
    void passwordCheck(OkHttpClient okHttpClient, DyUserEntity dyUserEntity);

    /**
     * 修改密码的请求
     * @param okHttpClient
     * @param dyUserEntity
     * @param phoneEntity
     */
    void passwordChange(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, PhoneEntity phoneEntity);

    /**
     * 修改密码发送短信验证码的请求
     * @param okHttpClient
     * @param dyUserEntity
     * @param phoneEntity
     */
    void passwordModifySendCode(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, PhoneEntity phoneEntity);

    /**
     * 310版本获取1104或1105等验证码的请求
     * @param okHttpClient
     * @param deviceEntity
     * @return
     */
    JSONObject identifyingCodeGet(OkHttpClient okHttpClient, DeviceEntity deviceEntity, String errorCode) throws IOException;

    /**
     * 发送确认验证码的请求
     * @param okHttpClient
     * @param deviceEntity
     * @param errorCode
     * @param codeId
     * @param result
     * @throws IOException
     */
    void identifyingCodeVerify(OkHttpClient okHttpClient, DeviceEntity deviceEntity, String errorCode, String codeId, ArrayList<HashMap<String, String>> result) throws IOException;

    /**
     * 给高翔的310发送验证码
     * @param okHttpClient
     * @param phoneEntity
     * @param deviceEntity
     * @return
     */
    JSONObject sendCode310ForGX(OkHttpClient okHttpClient, PhoneEntity phoneEntity, DeviceEntity deviceEntity);
}
