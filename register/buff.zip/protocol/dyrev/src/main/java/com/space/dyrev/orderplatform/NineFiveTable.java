package com.space.dyrev.orderplatform;

import java.util.HashMap;

/**
 * @program: protocol
 * @description: 95平台url请求与apikey存储表
 * @author: gaoxiang
 * @create: 2018-11-09 22:30
 **/
public class NineFiveTable {

    private static String thumbUpKey = "vmqma0sorXPLFuZF";
    private static String takePowerKey = "pV5GCAkJDwJEG2jy";

    public static HashMap<OrderEnum,String> thumbUpMap = new HashMap<>();

    public static HashMap<OrderEnum,String> takePowerMap = new HashMap<>();

    static {
        thumbUpMap.put(OrderEnum.Apikey,thumbUpKey);
        thumbUpMap.put(OrderEnum.QueueOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27022&state=dlz&format=json&apikey="+thumbUpKey);
        thumbUpMap.put(OrderEnum.UnBeginOrder," http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27022&state=wks&format=json&apikey="+thumbUpKey);
        thumbUpMap.put(OrderEnum.WorkingOrder," http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27022&state=jxz&format=json&apikey="+thumbUpKey);
        thumbUpMap.put(OrderEnum.CancelOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27022&state=tdz&format=json&apikey="+thumbUpKey);
        thumbUpMap.put(OrderEnum.ChangePasswordOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27022&state=gmz&format=json&apikey="+thumbUpKey);
        thumbUpMap.put(OrderEnum.WaitMoneyOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27022&state=xfz&format=json&apikey="+thumbUpKey);
        thumbUpMap.put(OrderEnum.WaitforUpOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27022&state=bdz&format=json&apikey="+thumbUpKey);
        thumbUpMap.put(OrderEnum.UpdateOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=edit&goods_id=27022&order_state=gmz&order_id=100&now_num=200&end_num=800&apikey="+thumbUpKey);
        thumbUpMap.put(OrderEnum.FinishOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=fulfil&order_id=#######&now_num=0&apikey="+thumbUpKey);
        thumbUpMap.put(OrderEnum.DeleteOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=refund&order_id=100&now_num=200&apikey="+thumbUpKey);
    }

    static {
        takePowerMap.put(OrderEnum.Apikey,takePowerKey);
        takePowerMap.put(OrderEnum.QueueOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27200&state=dlz&format=json&apikey="+takePowerKey);
        takePowerMap.put(OrderEnum.UnBeginOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27200&state=wks&format=json&apikey="+takePowerKey);
        takePowerMap.put(OrderEnum.WorkingOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27200&state=jxz&format=json&apikey="+takePowerKey);
        takePowerMap.put(OrderEnum.CancelOrder," http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27200&state=tdz&format=json&apikey="+takePowerKey);
        takePowerMap.put(OrderEnum.ChangePasswordOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27200&state=gmz&format=json&apikey="+takePowerKey);
        takePowerMap.put(OrderEnum.WaitMoneyOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27200&state=xfz&format=json&apikey="+takePowerKey);
        takePowerMap.put(OrderEnum.WaitforUpOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=down_orders&goods_id=27200&state=bdz&format=json&apikey="+takePowerKey);
        takePowerMap.put(OrderEnum.UpdateOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=edit&goods_id=27200&order_state=gmz&order_id=100&now_num=200&end_num=800&apikey="+takePowerKey);
        takePowerMap.put(OrderEnum.FinishOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=fulfil&order_id=#######&now_num=0&apikey="+takePowerKey);
        takePowerMap.put(OrderEnum.DeleteOrder,"http://dy18.95jw.cn/admin_jiuwuxiaohun.php?m=home&c=api&a=refund&order_id=100&now_num=200&apikey="+takePowerKey);
    }
}
