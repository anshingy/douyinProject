package com.space.dyrev.thread.service.tools;

import com.space.dyrev.commonentity.OrderEntity;
import com.space.dyrev.enumeration.OrderTypeEnum;
import com.space.dyrev.ordermodule.dao.OrderEntityRepository;
import com.space.dyrev.orderplatform.NineFiveOrderPlatform;
import com.space.dyrev.orderplatform.NullTypeException;
import com.space.dyrev.thread.service.impl.UserThreadServiceImpl;
import com.space.dyrev.util.springutils.SpringUtil;

import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * @program: hehedada
 * @description: 订单获取线程
 * @author: Mr.gao
 * @create: 2018-10-21 20:52
 **/
public class OrderGetterThread implements Runnable {

    // 0 标识待执行订单
    public static String orderStatus ="1";
    public static ArrayList<OrderEntity> linkedBlockingQueue;
    public static ArrayList<OrderEntity> followOrderQueue;
    public static OrderEntityRepository orderThreadDatabase;
    public static NineFiveOrderPlatform nineFiveOrderPlatform;
    public OrderGetterThread(ArrayList<OrderEntity> linkedBlockingQueue,ArrayList<OrderEntity> followOrderQueue){
        this.linkedBlockingQueue = linkedBlockingQueue;
        this.followOrderQueue = followOrderQueue;
    }

    @Override
    public void run() {
        if(orderThreadDatabase==null){
            orderThreadDatabase = SpringUtil.getBean(OrderEntityRepository.class);
        }
        System.out.println("##################################################################################################");
        try {
            nineFiveOrderPlatform = NineFiveOrderPlatform.getInstrance("点赞");
        } catch (NullTypeException e) {
            e.printStackTrace();
        }
        while (true){
            nineFiveOrderPlatform.getAllNewOrders();
            ArrayList<OrderEntity> orderEntities = orderThreadDatabase.findAllByStatus(orderStatus);
            for(int i =0;i<orderEntities.size();i++){
                OrderEntity orderEntity = orderEntities.get(i);
                orderEntity.setStatus("1");
                orderThreadDatabase.save(orderEntity);
            }
            synchronized (linkedBlockingQueue){
                synchronized (followOrderQueue){
                    for(OrderEntity orderEntity:orderEntities){
//                        OrderTypeEnum orderTypeEnum = orderEntity.getOrderTypeEnum();
//                        if(orderTypeEnum.getOrderType()<2){
//                            linkedBlockingQueue.add(orderEntity);
//                        }else{
//                            followOrderQueue.add(orderEntity);
//                        }
                        linkedBlockingQueue.add(orderEntity);
                    }
                }

            }
            System.out.println(orderEntities.size()+"##################################################################################################");

            try {
                Thread.sleep(60000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            break;
        }
    }
}
