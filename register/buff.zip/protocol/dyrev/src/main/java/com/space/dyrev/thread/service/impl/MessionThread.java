package com.space.dyrev.thread.service.impl;

import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.commonentity.HostIPPo;
import com.space.dyrev.commonentity.OrderEntity;
import com.space.dyrev.request.operationmodule.service.OperationService;
import com.space.dyrev.thread.service.UserThreadService;
import com.space.dyrev.thread.service.tools.IPThread;
import com.space.dyrev.thread.service.tools.OrderGetterThread;
import com.space.dyrev.thread.service.tools.UserGetterThread;
import com.space.dyrev.util.springutils.SpringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * @program: protocol
 * @description: 提供简单的线程实现的接口，方便用户的使用
 * @author: gaoxiang
 * @create: 2018-11-04 20:02
 **/
public class MessionThread {

    private static final Logger logger = LoggerFactory.getLogger(UserThreadServiceImpl.class);

    //存储订单、用户、IP的对象
    public static LinkedBlockingQueue<HostIPPo> hostIpQuene = new LinkedBlockingQueue<HostIPPo>();

    public static LinkedBlockingQueue<DyUserEntity> dyUserEntitiesQueue =new LinkedBlockingQueue<>();

    //注意加锁以及判断是否为空
    public static ArrayList<OrderEntity> thumbUpQueue = new ArrayList<>();

    public static ArrayList<OrderEntity> followQueue = new ArrayList<>();

    //分别管理信息存储对象的线程
    public static Thread ipThread = new Thread(new IPThread(hostIpQuene));

    public static Thread dyUserThread = new Thread(new UserGetterThread(dyUserEntitiesQueue));

    public static Thread orderThread = new Thread(new OrderGetterThread(thumbUpQueue,followQueue));

    public static OperationService operationService;

    private static MessionThread messionThread = new MessionThread();

    private MessionThread(){
        operationService = SpringUtil.getBean(OperationService.class);
    }

    public static MessionThread getInstrance(){
        return messionThread;
    }

    public void newlyLogin(){
        makeAllThreadAlive(false);
        logger.info("------------开始多线程重新登陆账户------------");
        UserThreadService asyncService = (UserThreadService) SpringUtil.getBean("asyncService");
        for (int i = 0; i < 40; i++) {
            asyncService.registerNewUser();
        }
        logger.info("------------对应状态的用户登陆完成------------");
    }

    public void diggAndthumbUp(){
        makeAllThreadAlive(true);
        logger.info("------------开始多线程进行点赞关注------------");
        UserThreadService asyncService = (UserThreadService) SpringUtil.getBean("asyncService");
        for (int i = 0; i < 20; i++) {
            asyncService.diggAndThumbUp();
        }
        logger.info("------------点赞和关注执行完成------------");
    }

    public void RegisterHaha(){
        //makeAllThreadAlive(true);
        logger.info("------------开始多线程进行点赞关注------------");
        UserThreadService asyncService = (UserThreadService) SpringUtil.getBean("asyncService");
        for (int i = 0; i < 20; i++) {
            asyncService.registerReallyUser();
        }
        logger.info("------------多线程注册执行完成------------");
    }
    private void makeAllThreadAlive(boolean needOrder){
        if(!ipThread.isAlive()){
            ipThread.start();
        }
        if(!dyUserThread.isAlive()){
            dyUserThread.start();
        }
        if(needOrder){
            if(!orderThread.isAlive()){
                orderThread.start();
            }

        }
    }
}
