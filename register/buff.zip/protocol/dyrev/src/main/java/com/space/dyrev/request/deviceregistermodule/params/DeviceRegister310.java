package com.space.dyrev.request.deviceregistermodule.params;

import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.request.commonparams.CommonParams;
import com.space.dyrev.util.httputil.CookieTool;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * @program: dyrev
 * @description: 310版本的device_register
 * @author: Mr.Jia
 * @create: 2018-11-10 21:35
 **/
public class DeviceRegister310 {

    // HOST
    private static final String HOST = "log.snssdk.com";

    // 请求头方法
    private static final String FUNC = "/service/2/device_register/?";

    /**
     * 构造url请求头
     * @param deviceEntity 设备实体类
     */
    public static String constructUrl(DeviceEntity deviceEntity) {

        String url = "https://" + HOST + FUNC + "ac="+deviceEntity.getAccess()+"&channel=meizu&aid=1128&app_name=aweme&version_code=310&version_name=3.1.0&device_platform=android&ssmix=a&device_type="+deviceEntity.getDeviceType()+"&device_brand="+deviceEntity.getDeviceBrand()+"&language=zh&os_api=25&os_version=7.1.2&uuid="+deviceEntity.getUuid()+"&openudid="+deviceEntity.getOpenudid()+"&manifest_version_code=310&resolution="+deviceEntity.getResolution()+"&dpi="+deviceEntity.getDpi()+"&update_version_code=3102&_rticket="+System.currentTimeMillis()+"&tt_data=a";

        return url;
    }

    /**
     * 构造header
     * @param deviceEntity
     * @return
     */
    public static Map constructHeader(DeviceEntity deviceEntity) {

        Map<String, String> header = new HashMap<String, String>();
        header.put("Accept-Encoding","gzip");
        header.put("X-SS-QUERIES","");
        header.put("X-SS-REQ-TICKET", String.valueOf(System.currentTimeMillis()));
        header.put("sdk-version","1");
        header.put("Content-Type","application/octet-stream;tt-data=a");
        header.put("Content-Length","1000");
        header.put("Host","log.snssdk.com");
        header.put("Connection","Keep-Alive");
        header.put("User-Agent","okhttp/3.10.0.1");

        return header;
    }

    public static JSONObject device_register_json(DeviceEntity deviceEntity) {

        String line = "{\"magic_tag\":\"ss_app_log\",\"header\":{\"display_name\":\"抖音短视频\"," +
                "\"update_version_code\":3102,\"manifest_version_code\":310,\"aid\":1128,\"channel\"" +
                ":\"meizu\",\"appkey\":\"57bfa27c67e58e7d920028d3\",\"package\":\"com.ss.android.ugc.aweme\"" +
                ",\"app_version\":\"3.1.0\",\"version_code\":310,\"sdk_version\":\"2.5.4.6\"," +
                "\"os\":\"Android\",\"os_version\":\"7.1.2\",\"os_api\":25," +
                "\"device_model\":\""+deviceEntity.getDeviceType()+"\"," +
                "\"device_brand\":\""+deviceEntity.getDeviceBrand()+"\"," +
                "\"device_manufacturer\":\""+deviceEntity.getDeviceBrand()+"\"," +
                "\"cpu_abi\":\"armeabi-v7a\",\"build_serial\":\""+deviceEntity.getBuildSerial()+"\"," +
                "\"release_build\":\"6f1412b_20181029\",\"density_dpi\":"+deviceEntity.getDpi()+"," +
                "\"display_density\":\"mdpi\",\"resolution\":\"1920x1080\",\"language\":\"zh\"," +
                "\"mc\":\"68:3e:34:1e:c3:9a\",\"timezone\":8,\"access\":\"wifi\"," +
                "\"not_request_sender\":0,\"carrier\":\"中国移动\",\"mcc_mnc\":\"46000\"," +
                "\"rom\":\"FLYME-1517208287\",\"rom_version\":\"\",\"sig_hash\":\""+deviceEntity.getSigHash()+"\"," +
                "\"device_id\":\""+deviceEntity.getDeviceId()+"\",\"openudid\":\""+deviceEntity.getOpenudid()+"\"," +
                "\"udid\":\""+deviceEntity.getUuid()+"\",\"clientudid\":\"0b26daf8-db1a-45f9-b80c-ff691a9063c8\"," +
                "\"serial_number\":\"850BBM422A9Q\",\"sim_serial_number\":[],\"region\":\"CN\"," +
                "\"tz_name\":\"Asia\\/Shanghai\",\"tz_offset\":28800,\"sim_region\":\"cn\"}," +
                "\"_gen_time\":"+System.currentTimeMillis()+"}";
        JSONObject result = null;
        try {
            result = new JSONObject(line);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return result;
    }
}
