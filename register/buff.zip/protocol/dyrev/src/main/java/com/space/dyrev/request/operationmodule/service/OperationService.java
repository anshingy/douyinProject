package com.space.dyrev.request.operationmodule.service;

import com.alibaba.fastjson.JSONObject;
import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.commonentity.PhoneEntity;
import com.space.dyrev.enumeration.VersionEnum;
import com.space.dyrev.util.httputil.OkHttpTool;
import okhttp3.OkHttpClient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

/**
 *           .]]]]]]`.            .]]]]`           .]]]]].            .,]]]]]`        .]]]]`
 *         ,@@@@@@@@@@^    @@@@./@@@@@@@@@^    =@@@@@@@@@@@@.      ]@@@@@@@@@@@^   ,@@@@@@@@@@`
 *        .@@@@`    .[`    @@@@@@@[`..[@@@@@   =@/`    .\@@@@    ,@@@@@[.    ,[.  /@@@/.  .\@@@\
 *        =@@@\            @@@@/.       @@@@^            @@@@   ,@@@@/           /@@@^      =@@@^
 *         \@@@@@]`        @@@@.        =@@@@        ...]@@@@   =@@@@           .@@@@]]]]]]]]@@@@
 *          ,\@@@@@@@]     @@@@.        .@@@@   ,@@@@@@@@@@@@   @@@@^           =@@@@@@@@@@@@@@@@
 *              ,\@@@@@`   @@@@.        =@@@@ ,@@@@/.    @@@@   =@@@@           .@@@@
 *                 =@@@@   @@@@.        /@@@^ @@@@.      @@@@   ,@@@@^           \@@@\
 *        =].      =@@@/   @@@@@]     ./@@@/  @@@@\    ,/@@@@`   ,@@@@@`      ,`  \@@@@`       .`
 *        =@@@@@@@@@@@/    @@@@@@@@@@@@@@@`   .@@@@@@@@@@/@@@@@^  .\@@@@@@@@@@@^   ,@@@@@@@@@@@@@
 *         ,[\@@@@@[`      @@@@..[\@@@@[.       .[@@@@[.  ,\@@@[     ,[@@@@@/[`.      ,[@@@@@/[`.
 *                         @@@@.
 *                         @@@@.
 *                         @@@@.
 *
 *        @Author: space
 *        @Date: 2018/10/24 19:26
 *        @Description:
 **/
public interface OperationService {


    /**
     * 点赞的函数
     * https://aweme.snssdk.com/aweme/v1/commit/item/digg？
     * @param dyUserEntity 包括设备信息的实体类
     * @param awemeId 视频id
     * @return 点赞失败返回字符串1
     */
    String digg(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, String awemeId);

    /**
     * 关注的函数
     * https://aweme.snssdk.com/aweme/v1/commit/follow/user/?
     * @param okHttpClient http对象
     * @param dyUserEntity 帐号实体类
     * @param userId 关注id
     * @return 关注成功返回imprid 失败返回 1
     */
    String follow(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, String userId);


    /**
     * 修改个人信息
     * https://api.amemv.com/aweme/v1/commit/user/?
     * @param okHttpClient http对象
     * @param dyUserEntity 帐号实体类
     * @return
     */
    String modify(OkHttpClient okHttpClient, DyUserEntity dyUserEntity);

    /**
     * 搜索用户
     * https://aweme.snssdk.com/aweme/v1/user/?user_id=83908293618&ts=1540733910&app_type=normal&os_api=23&device_type=Redmi%204X&device_platform=android&ssmix=a&iid=46777879533&manifest_version_code=270&dpi=320&uuid=866709039379945&version_code=270&app_name=aweme&version_name=2.7.0&openudid=3e05931eec1a90af&device_id=58306217792&resolution=720*1280&os_version=6.0.1&language=zh&device_brand=Xiaomi&ac=mobile&update_version_code=2702&aid=1128&channel=wandoujia&_rticket=1540733912797&as=a165bb8d36cd8bdb354355&cp=b5d3b9586058d6b9e1OoWw&mas=01c8d4152976e2d9b661e30acf749710d9acaccc2caccc4626461c HTTP/1.1
     * @param okHttpClient
     * @param userId
     */
    void searchUser(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, String userId);


    /**
     * 用密码登陆
     * https://is.snssdk.com/passport/mobile/login/?os_api=23&device_type=Redmi+4X&device_platform=android&ssmix=a&iid=46777879533&manifest_version_code=270&dpi=320&uuid=866709038462304&version_code=270&app_name=aweme&version_name=2.7.0&openudid=3e05931eec1a90af&device_id=58306217792&resolution=720*1280&os_version=6.0.1&language=zh&device_brand=Xiaomi&ac=mobile&update_version_code=2702&aid=1128&channel=wandoujia&_rticket=1540803655251&ts=1540803653&as=a1a57cad35f47b3cf64355&cp=cd4cb75c516cdfcce1IgQk&mas=019217fc6d787cf4c211ec1dcc41c7a638acaccc2c6c66c6cc46ec HTTP/1.1
     * @param okHttpClient
     * @param dyUserEntity
     * @param captcha 如果为""或者 null则为空
     */
    DyUserEntity passportMobileLogin(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, String captcha) throws Exception;

    /**
     * 来自贾莛的密码登录
     * @param okHttpClient
     * @param dyUserEntity
     * @return
     * @throws Exception
     */
    DyUserEntity login(OkHttpClient okHttpClient, DyUserEntity dyUserEntity) throws Exception;

    /**
     * space的密码登录
     * @param okHttpClient
     * @param dyUserEntity
     * @return
     * @throws Exception
     */
    DyUserEntity login310(OkHttpClient okHttpClient, DyUserEntity dyUserEntity) throws Exception;


    /**
     * 根据视频id获取用户id的方法
     * @param okHttpClient
     * @param aweme_id
     * @return
     */
    String getUidByVideoId(OkHttpClient okHttpClient,String aweme_id) throws Exception;


    /**
     * 来自贾莛的点赞
     * @param okHttpClient
     * @param dyUserEntity
     * @param aweme_id
     * @return
     */
    boolean digg270(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, String aweme_id);

    /**
     * 拉取视频的
     * @param okHttpClient
     * @param dyUserEntity
     * @return
     */
    ArrayList<String> feed(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, DeviceEntity deviceEntity);

    /**
     * 拉取视频的 返回一串json
     * @param okHttpClient
     * @param dyUserEntity
     * @param deviceEntity
     * @param type "json" 返回json格式的
     * @return {"impr_id":"xxxxxxxxxxxxxxxx", "aweme_list":[{"author_id":"999999999","aweme_id":"999999999"},{{"authorId":"999999999","videoId":"999999999"}}]}
     */
    JSONObject feed(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, DeviceEntity deviceEntity, String type);


    /**
     * 刷浏览量的请求
     * @param okHttpClient
     * @param dyUserEntity
     * @param awemeId
     */
    void BrowseVideo(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, String awemeId);

    /**
     * https://aweme.snssdk.com/aweme/v1/commit/item/digg/?aweme_id=6622071563271277827&type=1&retry_type=no_retry&iid=50689762807&device_id=58306217792&ac=mobile&channel=wandoujia_zhiwei&aid=1128&app_name=aweme&version_code=310&version_name=3.1.0&device_platform=android&ssmix=a&device_type=Redmi+4X&device_brand=Xiaomi&language=zh&os_api=23&os_version=6.0.1&uuid=866709032763749&openudid=3e05931eec1a90af&manifest_version_code=310&resolution=720*1280&dpi=320&update_version_code=3102&_rticket=1541855257633&ts=1541855257&js_sdk_version=1.2.2&as=a1c5bd9e3981db38662566&cp=d419b95f9a66ec86e1Ws_a&mas=01ed74b90a8d2fabd275c6ab011e0f5d896c6cac4c6c6c1ccc4626 HTTP/1.1
     * @param okHttpClient
     * @param dyUserEntity
     * @param aweme_id
     * @return
     */
    boolean digg310(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, String aweme_id) throws IOException;

    /**
     * 视频点赞根据版本
     * @param okHttpClient okhttpclient
     * @param dyUserEntity 用户实体类
     * @param awemeId 视频id
     * @param versionEnum 版本信息
     * @return 返回成功或者失败
     */
    boolean diggByVersionn(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, String awemeId, VersionEnum versionEnum) throws IOException;

    /**
     * 310版本关注请求
     * @param okHttpClient
     * @param dyUserEntity
     * @param userId
     * @return
     */
    boolean follow310(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, String userId) throws IOException;

    /**
     * 310版本修改个人信息的请求
     * 下面是info实例，一次只发一对键值，尽管我代码实现是循环的都能加进去，但是保险起见还是一对
     * info.put("nickname","卖报の行家");  这是昵称
     * info.put("signature","啦啦啦我是卖报的大牛");  这是描述
     * info.put("birthday","1992-10-12");  生日
     * @param okHttpClient
     * @param dyUserEntity
     * @param info 特别说明，310版本修改信息请求有变动，每次请求只能修改一条信息，所以Map info只能包含一对键值
     * @return
     */
    String modify310(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, Map<String, String> info) throws IOException;

    /**
     * 获取用户信息的请求
     * @param okHttpClient
     * @param dyUserEntity
     */
    public boolean getUserInfo310(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, String userId) throws IOException;
}
