package com.space.dyrev.encrypt;

import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.security.SecureRandom;
import java.util.Base64;

/**
 *           .]]]]]]`.            .]]]]`           .]]]]].            .,]]]]]`        .]]]]`
 *         ,@@@@@@@@@@^    @@@@./@@@@@@@@@^    =@@@@@@@@@@@@.      ]@@@@@@@@@@@^   ,@@@@@@@@@@`
 *        .@@@@`    .[`    @@@@@@@[`..[@@@@@   =@/`    .\@@@@    ,@@@@@[.    ,[.  /@@@/.  .\@@@\
 *        =@@@\            @@@@/.       @@@@^            @@@@   ,@@@@/           /@@@^      =@@@^
 *         \@@@@@]`        @@@@.        =@@@@        ...]@@@@   =@@@@           .@@@@]]]]]]]]@@@@
 *          ,\@@@@@@@]     @@@@.        .@@@@   ,@@@@@@@@@@@@   @@@@^           =@@@@@@@@@@@@@@@@
 *              ,\@@@@@`   @@@@.        =@@@@ ,@@@@/.    @@@@   =@@@@           .@@@@
 *                 =@@@@   @@@@.        /@@@^ @@@@.      @@@@   ,@@@@^           \@@@\
 *        =].      =@@@/   @@@@@]     ./@@@/  @@@@\    ,/@@@@`   ,@@@@@`      ,`  \@@@@`       .`
 *        =@@@@@@@@@@@/    @@@@@@@@@@@@@@@`   .@@@@@@@@@@/@@@@@^  .\@@@@@@@@@@@^   ,@@@@@@@@@@@@@
 *         ,[\@@@@@[`      @@@@..[\@@@@[.       .[@@@@[.  ,\@@@[     ,[@@@@@/[`.      ,[@@@@@/[`.
 *                         @@@@.
 *                         @@@@.
 *                         @@@@.
 *                                                                                             @ClassName Ces
 *                                                                                             @Author: space
 *                                                                                             @Description TODO 
 *                                                                                             @Date: 2018/10/11 23:29
 **/
public class Ces {
    private static String key = "QExW+yCCI44Ft4pE";

    private DeviceEntity deviceEntity = new DeviceEntity();



    public String decode(byte[] bArr) {
        String result;
        SecureRandom secureRandom = new SecureRandom();
//        Key k = result.
        return null;
    }


     public static void main(String[] args) {
        Ces ces = new Ces();
         Class<? extends Ces> aClass = ces.getClass();
         Field[] declaredFields = aClass.getDeclaredFields();

         for (Field f : declaredFields) {
             if (f.getName().equals("deviceEntity")){
                 try {
//                     Field[] declaredFields1 = f.getType().getDeclaredFields();
//                     for (Field field:declaredFields1) {
//                         field.get
//                         System.out.println(field);
//                     }
                     Class<?> type = f.getType();
                     Constructor con = type.getConstructor();
                     Object obj = con.newInstance();

                     Method[] declaredMethods = type.getDeclaredMethods();
                     for (Method method : declaredMethods) {
                         if (method.getName().equals("say")) {
                             method.invoke(obj, "helloworld");
                         }
                     }
//                     System.out.println(f.getType());
                 } catch (Exception e) {
                     e.printStackTrace();
                 }
             }
         }
     }

}
