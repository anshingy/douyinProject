package com.space.dyrev.request.applogmodule.service;

import com.alibaba.fastjson.JSONObject;
import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.enumeration.VersionEnum;
import okhttp3.OkHttpClient;

import java.io.IOException;

/**
 *           .]]]]]]`.            .]]]]`           .]]]]].            .,]]]]]`        .]]]]`
 *         ,@@@@@@@@@@^    @@@@./@@@@@@@@@^    =@@@@@@@@@@@@.      ]@@@@@@@@@@@^   ,@@@@@@@@@@`
 *        .@@@@`    .[`    @@@@@@@[`..[@@@@@   =@/`    .\@@@@    ,@@@@@[.    ,[.  /@@@/.  .\@@@\
 *        =@@@\            @@@@/.       @@@@^            @@@@   ,@@@@/           /@@@^      =@@@^
 *         \@@@@@]`        @@@@.        =@@@@        ...]@@@@   =@@@@           .@@@@]]]]]]]]@@@@
 *          ,\@@@@@@@]     @@@@.        .@@@@   ,@@@@@@@@@@@@   @@@@^           =@@@@@@@@@@@@@@@@
 *              ,\@@@@@`   @@@@.        =@@@@ ,@@@@/.    @@@@   =@@@@           .@@@@
 *                 =@@@@   @@@@.        /@@@^ @@@@.      @@@@   ,@@@@^           \@@@\
 *        =].      =@@@/   @@@@@]     ./@@@/  @@@@\    ,/@@@@`   ,@@@@@`      ,`  \@@@@`       .`
 *        =@@@@@@@@@@@/    @@@@@@@@@@@@@@@`   .@@@@@@@@@@/@@@@@^  .\@@@@@@@@@@@^   ,@@@@@@@@@@@@@
 *         ,[\@@@@@[`      @@@@..[\@@@@[.       .[@@@@[.  ,\@@@[     ,[@@@@@/[`.      ,[@@@@@/[`.
 *                         @@@@.
 *                         @@@@.
 *                         @@@@.
 *
 *        @Author: space
 *        @Date: 2018/10/26 16:09
 *        @Description:
 **/
public interface AppLogService {


    /**
     * TTEncrypt加密的方法
     * https://log.snssdk.com/service/2/log_settings/?iid=46777879533&device_id=58306217792&ac=3g&channel=wandoujia&aid=1128&app_name=aweme&version_code=270&version_name=2.7.0&device_platform=android&ssmix=a&device_type=Redmi+4X&device_brand=Xiaomi&language=zh&os_api=23&os_version=6.0.1&uuid=866709036507209&openudid=3e05931eec1a90af&manifest_version_code=270&resolution=720*1280&dpi=320&update_version_code=2702&_rticket=1540484657657&tt_data=a
     * @param deviceEntity
     */
    void service2LogSettingS(OkHttpClient okHttpClient, DeviceEntity deviceEntity);


    /**
     * applpg
     * https://log.snssdk.com/service/2/app_log/?iid=46777879533&device_id=58306217792&ac=mobile&channel=wandoujia&aid=1128&app_name=aweme&version_code=270&version_name=2.7.0&device_platform=android&ssmix=a&device_type=Redmi+4X&device_brand=Xiaomi&language=zh&os_api=23&os_version=6.0.1&uuid=866709036507209&openudid=3e05931eec1a90af&manifest_version_code=270&resolution=720*1280&dpi=320&update_version_code=2702&_rticket=1540484697715&tt_data=a HTTP/1.1
     * @param okHttpClient
     * @param deviceEntity
     */
    void service2AppLog(OkHttpClient okHttpClient, DeviceEntity deviceEntity);


    /**
     * 登陆后的applog
     * @param okHttpClient
     * @param dyUserEntity
     */
    void service2AppLog(OkHttpClient okHttpClient, DyUserEntity dyUserEntity);

    void service2AppLog(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, JSONObject body);

    void Applog270(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, String aweme_id);

    /**
     * 310版本的applog
     * @param okHttpClient
     * @param dyUserEntity
     * @param aweme_id
     */
    void Applog310(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, String aweme_id);

    /**
     * applog 注册设备的applog
     * @param okHttpClient 加上代理的okHttpClient
     * @param dyUserEntity 用户实体类
     * @param versionEnum 版本枚举类
     */
    void applog(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, VersionEnum versionEnum) throws Exception;

    /**
     * 配合applogManager使用的接口
     * @param okHttpClient
     * @param dyUserEntity
     * @param body
     */
    void applogWithJson(OkHttpClient okHttpClient, DyUserEntity dyUserEntity, JSONObject body, VersionEnum version) throws IOException;
}
