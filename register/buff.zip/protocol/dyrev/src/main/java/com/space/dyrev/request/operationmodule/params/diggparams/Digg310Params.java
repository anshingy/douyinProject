package com.space.dyrev.request.operationmodule.params.diggparams;

import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.request.commonparams.CommonParams;
import com.space.dyrev.util.httputil.CookieTool;

import java.util.HashMap;
import java.util.Map;

/**
 *           .]]]]]]`.            .]]]]`           .]]]]].            .,]]]]]`        .]]]]`
 *         ,@@@@@@@@@@^    @@@@./@@@@@@@@@^    =@@@@@@@@@@@@.      ]@@@@@@@@@@@^   ,@@@@@@@@@@`
 *        .@@@@`    .[`    @@@@@@@[`..[@@@@@   =@/`    .\@@@@    ,@@@@@[.    ,[.  /@@@/.  .\@@@\
 *        =@@@\            @@@@/.       @@@@^            @@@@   ,@@@@/           /@@@^      =@@@^
 *         \@@@@@]`        @@@@.        =@@@@        ...]@@@@   =@@@@           .@@@@]]]]]]]]@@@@
 *          ,\@@@@@@@]     @@@@.        .@@@@   ,@@@@@@@@@@@@   @@@@^           =@@@@@@@@@@@@@@@@
 *              ,\@@@@@`   @@@@.        =@@@@ ,@@@@/.    @@@@   =@@@@           .@@@@
 *                 =@@@@   @@@@.        /@@@^ @@@@.      @@@@   ,@@@@^           \@@@\
 *        =].      =@@@/   @@@@@]     ./@@@/  @@@@\    ,/@@@@`   ,@@@@@`      ,`  \@@@@`       .`
 *        =@@@@@@@@@@@/    @@@@@@@@@@@@@@@`   .@@@@@@@@@@/@@@@@^  .\@@@@@@@@@@@^   ,@@@@@@@@@@@@@
 *         ,[\@@@@@[`      @@@@..[\@@@@[.       .[@@@@[.  ,\@@@[     ,[@@@@@/[`.      ,[@@@@@/[`.
 *                         @@@@.
 *                         @@@@.
 *                         @@@@.
 *                                                                                             @ClassName Digg310Params
 *                                                                                             @Author: space
 *                                                                                             @Description TODO
 *                                                                                             @Date: 2018/10/11 23:29
 **/
public class Digg310Params {
    // HOST
    private static final String HOST = "api.amemv.com";

    // 请求头方法
    private static final String FUNC = "/aweme/v1/commit/item/digg/?";

    /**
     * 构造url请求头
     * @param dyUserEntity 帐号实体类
     * @param awemeId 视频id
     */
    public static String constructUrl(DyUserEntity dyUserEntity, String awemeId) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();
        String url = "https://api.amemv.com/aweme/v1/commit/item/digg/?aweme_id="+awemeId+"&type=1&channel_id=0&retry_type=no_retry&iid="+deviceEntity.getInstallId()+"&device_id="+deviceEntity.getDeviceId()+"&ac=wifi&channel=meizu&aid=1128&app_name=aweme&version_code=310&version_name=3.1.0&device_platform=android&ssmix=a&device_type="+deviceEntity.getDeviceType()+"&device_brand="+deviceEntity.getDeviceBrand()+"&language=zh&os_api=25&os_version=7.1.2&uuid="+deviceEntity.getUuid()+"&openudid="+deviceEntity.getOpenudid()+"&manifest_version_code=310&resolution="+deviceEntity.getResolution()+"&dpi="+deviceEntity.getDpi()+"&update_version_code=3102&_rticket="+System.currentTimeMillis()+"&ts="+System.currentTimeMillis()/1000+"&js_sdk_version=1.2.2&as=a1iosdfgh&cp=androide1";

        return url;
    }

    /**
     * 构造header
     * @param dyUserEntity
     * @return
     */
    public static Map constructHeader(DyUserEntity dyUserEntity) {

        Map<String, String> header = new HashMap<String, String>();
        header.put("Host","api.amemv.com");
        header.put("Connection","keep-alive");
        header.put("Accept-Encoding","gzip");
        header.put("sdk-version", "1");
        header.put("X-SS-TC","0");
        header.put("X-Tt-Token","");
        header.put("Cookie", CookieTool.getCookieFromDevAndAcc(dyUserEntity.getDevice(), dyUserEntity));
        header.put("User-Agent",CommonParams.getUserAgent(dyUserEntity.getDevice().getDeviceType()));

        return header;
    }
}
