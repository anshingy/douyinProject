package com.space.dyrev.request.accountregistermodule.params;

import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.request.commonparams.CommonParams;

import java.util.HashMap;
import java.util.Map;

/**
 * @program: dyrev
 * @description: 310版本验证码处理请求的参数构造类
 * @author: Mr.Jia
 * @create: 2018-11-15 23:12
 **/
public class IdentifyingCode310Params {

    private static final String GET_HOST = "verify.snssdk.com";

    private static final String GET_FUNC = "/get?";

    private static final String VERIFY_HOST = "verify.snssdk.com";

    private static final String VERIFY_FUNC = "/verify?";

    /**
     * 构造url
     * @param deviceEntity
     * @return
     */
    public static String constructGetUrl (DeviceEntity deviceEntity, String errorCode) {

        String url = "https://"+GET_HOST+GET_FUNC+"aid=1128&lang=zh-hans&app_name=aweme&iid="+deviceEntity.getInstallId()+"&vc=310&did="+deviceEntity.getDeviceId()+"&ch=meizu&os=0&challenge_code="+errorCode;

        return url;
    }

    /**
     * 构造header
     * @return
     */
    public static Map constructGetHeader(DeviceEntity deviceEntity, String url) {

        Map<String, String> header = new HashMap<String, String>();
        header.put("Host",GET_HOST);
        header.put("Connection","keep-alive");
        header.put("Pragma","no-cache");
        header.put("Cache-Control","no-cache");
        header.put("Accept","application/json");
        header.put("X-Requested-With","XMLHttpRequest");
        header.put("User-Agent","Mozilla/5.0 (Linux; Android "+ CommonParams.OS_VERSION+"; "+deviceEntity.getDeviceType()+" Build/LMY47I; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/44.0.2403.147 Mobile Safari/537.36");
        header.put("Referer",url);
        header.put("Accept-Encoding","gzip, deflate");
        header.put("Accept-Language","zh-CN,en-US;q=0.8");
        header.put("Cookie","install_id="+deviceEntity.getInstallId()+";qh[360]=1;");

        return header;
    }

    /**
     * 构造url
     * @param deviceEntity
     * @return
     */
    public static String constructVerifyUrl (DeviceEntity deviceEntity, String errorCode) {

        String url = "https://"+VERIFY_HOST+VERIFY_FUNC+"aid=1128&lang=zh-hans&app_name=aweme&iid="+deviceEntity.getInstallId()+"&vc=310&did="+deviceEntity.getDeviceId()+"&ch=meizu&os=0&challenge_code="+errorCode;

        return url;
    }

    /**
     * 构造header
     * @return
     */
    public static Map constructVerifyHeader(DeviceEntity deviceEntity, String url) {

        Map<String, String> header = new HashMap<String, String>();
        header.put("Host",GET_HOST);
        header.put("Connection","keep-alive");
        header.put("Content-Length","500");
        header.put("Pragma","no-cache");
        header.put("Cache-Control","no-cache");
        header.put("Accept","application/json");
        header.put("Origin","https://"+VERIFY_HOST);
        header.put("X-Requested-With","XMLHttpRequest");
        header.put("User-Agent","Mozilla/5.0 (Linux; Android "+ CommonParams.OS_VERSION+"; "+deviceEntity.getDeviceType()+" Build/LMY47I; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/44.0.2403.147 Mobile Safari/537.36");
        header.put("Content-Type","application/json");
        header.put("Referer",url);
        header.put("Accept-Encoding","gzip, deflate");
        header.put("Accept-Language","zh-CN,en-US;q=0.8");
        header.put("Cookie","install_id="+deviceEntity.getInstallId()+";qh[360]=1; sec_sessionid=");

        return header;
    }
}
