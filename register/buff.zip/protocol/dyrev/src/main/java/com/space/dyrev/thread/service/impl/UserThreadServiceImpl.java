package com.space.dyrev.thread.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.mysql.cj.x.protobuf.Mysqlx;
import com.space.dyrev.apisupport.ruokuaiPlatform.RuoKuaiApi;
import com.space.dyrev.commonentity.*;
import com.space.dyrev.dao.DeviceRepository;
import com.space.dyrev.dao.DyUserRepository;
import com.space.dyrev.enumeration.PhoneArea;
import com.space.dyrev.ordermodule.dao.OrderEntityRepository;
import com.space.dyrev.orderplatform.NineFiveOrderPlatform;
import com.space.dyrev.orderplatform.NullTypeException;
import com.space.dyrev.request.accountregistermodule.service.AccountRegisterService;
import com.space.dyrev.request.deviceregistermodule.service.DeviceRegisterService;
import com.space.dyrev.systemprocess.registerprocess.service.RegisterProcess;
import com.space.dyrev.thread.service.UserThreadService;
import com.space.dyrev.thread.service.tools.RegisterAction;
import okhttp3.OkHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.Proxy;
import javax.annotation.Resource;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import static com.space.dyrev.thread.service.tools.RegisterAction.emailGetter;

/**
 *           .]]]]]]`.            .]]]]`           .]]]]].            .,]]]]]`        .]]]]`
 *         ,@@@@@@@@@@^    @@@@./@@@@@@@@@^    =@@@@@@@@@@@@.      ]@@@@@@@@@@@^   ,@@@@@@@@@@`
 *        .@@@@`    .[`    @@@@@@@[`..[@@@@@   =@/`    .\@@@@    ,@@@@@[.    ,[.  /@@@/.  .\@@@\
 *        =@@@\            @@@@/.       @@@@^            @@@@   ,@@@@/           /@@@^      =@@@^
 *         \@@@@@]`        @@@@.        =@@@@        ...]@@@@   =@@@@           .@@@@]]]]]]]]@@@@
 *          ,\@@@@@@@]     @@@@.        .@@@@   ,@@@@@@@@@@@@   @@@@^           =@@@@@@@@@@@@@@@@
 *              ,\@@@@@`   @@@@.        =@@@@ ,@@@@/.    @@@@   =@@@@           .@@@@
 *                 =@@@@   @@@@.        /@@@^ @@@@.      @@@@   ,@@@@^           \@@@\
 *        =].      =@@@/   @@@@@]     ./@@@/  @@@@\    ,/@@@@`   ,@@@@@`      ,`  \@@@@`       .`
 *        =@@@@@@@@@@@/    @@@@@@@@@@@@@@@`   .@@@@@@@@@@/@@@@@^  .\@@@@@@@@@@@^   ,@@@@@@@@@@@@@
 *         ,[\@@@@@[`      @@@@..[\@@@@[.       .[@@@@[.  ,\@@@[     ,[@@@@@/[`.      ,[@@@@@/[`.
 *                         @@@@.
 *                         @@@@.
 *                         @@@@.
 *
 *        @Author: space
 *        @Date: 2018/10/24 00:38
 *        @Description:
 **/
@Service("asyncService")
public class UserThreadServiceImpl implements UserThreadService {

    private static final Logger logger = LoggerFactory.getLogger(UserThreadServiceImpl.class);

    //与逻辑相关的静态对象
    @Resource
    protected DyUserRepository dyUserRepository;
    @Resource
    protected DeviceRepository deviceRepository;
    @Resource
    protected OrderEntityRepository orderEntityRepository;
    @Resource
    private DeviceRegisterService deviceRegisterService;
    @Resource
    private AccountRegisterService accountRegisterService;

    @Resource
    public RegisterProcess registerProcess;

    @Override
    @Async("asyncServiceExecutor")
    public void registerNewUser() {
        OkHttpClient okHttpClient;
        do{
            for(int i =0;i<2;i++){
                okHttpClient = getOkhttpForWork();
                DyUserEntity dyUserEntity = null;
                try {
                    logger.info(Thread.currentThread()+" 正在运行");
                    dyUserEntity = MessionThread.dyUserEntitiesQueue.take();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                try {
                    registerProcess.passwordLoginV310(okHttpClient,dyUserEntity);
                } catch (Exception e) {
                    logger.info("出现了未知错误");
                    e.printStackTrace();
                }

            }
        }while (true);
    }

    /**
     * 注意，现在存在换ip的潜在漏洞
     */
    @Override
    @Async("asyncServiceExecutor")
    public void diggAndThumbUp() {
        //logger.info("tmd");
        OkHttpClient okHttpClient = getOkhttpForWork();
        //logger.info("不会是你吧");
        DyUserEntity dyUserEntity = null;
        OrderEntity orderEntity =null;
        int ipNum =0;
        do{
            int errorNum = 0;
            try {
                dyUserEntity = MessionThread.dyUserEntitiesQueue.take();
                //logger.info(dyUserEntity.getAccountStatus()+"############"+dyUserEntity.getId());
                if(dyUserEntity.getAccountStatus().equals("1")){
                    try {
                        registerProcess.passwordLoginV310(okHttpClient,dyUserEntity);
                        dyUserEntity = dyUserRepository.findById(dyUserEntity.getId()).get();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if(!dyUserEntity.getAccountStatus().equals("0")){
                        continue;
                    }
                }else if(dyUserEntity.getAccountStatus().equals("2")){
                    long now = new Date().getTime();
                    long userTime = dyUserEntity.getDiggTime();
                    if((now - userTime)>22*60*60*1000){

                    }else{
                        continue;
                    }
                }
                for(int i = 0; i<MessionThread.thumbUpQueue.size(); i++){
                    if(MessionThread.thumbUpQueue.size()<i){
                        logger.info("有订单完成啦，哥哥预测到java可能出现的错误，所以在这里给你speak下啦");
                        break;
                    }else if(MessionThread.thumbUpQueue.size()==0){
                        logger.info("现在全部订单都完成了，直接停止10分钟，不浪费资源撒");
                        Thread.sleep(3600000);
                    }
                    orderEntity =MessionThread.thumbUpQueue.get(i);
                    boolean result = false;
                    try {
                        result = thumbUpForThreeTimes(okHttpClient,orderEntity,dyUserEntity,0);
                    } catch (Exception e) {
                        e.printStackTrace();
                        okHttpClient = getOkhttpForWork();
                        if(i>0){
                            i--;
                        }
                        ipNum =0;
                        result = true;
                    }
                    logger.info(dyUserEntity.getId()+"点赞结果为: "+result);
                    if(result){

                    }else{
                        errorNum++;
                        int kao = orderEntity.getOrderCount();
                        kao ++;
                        orderEntity.setOrderCount(kao);
//                        if(kao >100){
//                            orderEntity.setStatus("-1");
//                            orderEntityRepository.save(orderEntity);
//                            synchronized (MessionThread.thumbUpQueue){
//                                MessionThread.thumbUpQueue.remove(orderEntity);
//                            }
//                        }
                    }
                    ipNum++;
                    if(ipNum>=40){
                        okHttpClient =getOkhttpForWork();
                        ipNum =0;
                    }
                    if(errorNum>6){
                        dyUserEntity.setAccountStatus("2");
                        logger.info("有个号点赞失败超过6次了，剥夺他点赞的权力");
                        break;
                    }
                }
                logger.info(dyUserEntity.getId()+"点赞数量为: "+dyUserEntity.getDiggCount());
                dyUserEntity.setDiggTime(new Date().getTime());
                dyUserRepository.save(dyUserEntity);

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }while (true);


    }

    @Override
    @Async("asyncServiceExecutor")
    public void registerReallyUser() {
        RegisterAction registerAction = new RegisterAction();
        do{
            OkHttpClient okHttpClient = getOkhttpForWork();
            for(int i=0;i<3;i++){
                registerAction.registerUserByV310(okHttpClient);
            }
        }while (true);
    }

    @Override
    @Async("asyncServiceExecutor")
    public void threadTest() {

        OkHttpClient okHttpClient = new OkHttpClient();
        registerAccount(okHttpClient);
    }

    public boolean thumbUpForThreeTimes(OkHttpClient okHttpClient,OrderEntity orderEntity,DyUserEntity dyUserEntity,int turns) throws IOException {
        boolean result = MessionThread.operationService.digg310(okHttpClient,dyUserEntity,orderEntity.getVideoId());;
        Random random = new Random();
        try {
            Thread.sleep((long) (Math.abs(random.nextDouble() - 0.5)/2*10000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if(turns>=3){
            return false;
        }
        if(result){
            //点赞成功时
            successThumbUp(orderEntity,dyUserEntity);
            return result;
        }else {
            //点赞失败时
            return thumbUpForThreeTimes(okHttpClient,orderEntity,dyUserEntity,turns+1);
        }
    }

    public void registerAccount(OkHttpClient okHttpClient){

        DyUserEntity dyUserEntity = new DyUserEntity();
        DeviceEntity deviceEntity = DeviceEntity.newDevice();
        deviceEntity = deviceRegisterService.deviceRegister310(okHttpClient, deviceEntity);
        //新创建设备存到数据库
//        deviceRepository.save(deviceEntity);
        dyUserEntity.setDevice(deviceEntity);

        //在平台取个号
        PhoneEntity phoneEntity = new PhoneEntity();
        try {
//            while(phoneEntity == null){
//
//                logger.info("再来一次");
//            }
            phoneEntity.setArea(PhoneArea.TG);
            phoneEntity.setPhoneNum("876564532");
//            phoneEntity = emailGetter.getPhoneNumber(okHttpClient);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("取到号");
        System.out.println(phoneEntity.getArea().getAreaNum());
        System.out.println(phoneEntity.getPhoneNum());
        //选区号，现在是泰国
//        phoneEntity.setArea(PhoneArea.TG);

        if (phoneEntity.getPhoneNum() != null && !phoneEntity.getPhoneNum().equals("")) {
            try {
                //返回jsonObject，高翔你自己判断是不是error和1104，取出来
                JSONObject json = accountRegisterService.sendCode310ForGX(okHttpClient, phoneEntity, deviceEntity);
                logger.info("----- 发送送验证码 -----请求结果 -> result = {}",json.toJSONString());
                String status = json.getString("message");
                if(status.equals("error")){
                    org.json.JSONObject jsonObject = new org.json.JSONObject(json.getJSONObject("data"));
                    String errorCode = jsonObject.getString("error_code");
                    logger.info("----- 验证码错误码 "+errorCode+" -----");
                    if(errorCode.equals("1104")){
                        //如果1104发送请求获取验证码图片的两个url和验证码的id
                        JSONObject jsonObject1 = accountRegisterService.identifyingCodeGet(okHttpClient, deviceEntity, errorCode);
                        JSONObject jsonObject2 = jsonObject1.getJSONObject("data");
                        //验证码确认,确认后会发送验证码
                        String codeId = jsonObject2.getString("id"); //上面这个请求拿到的
                        //因为平台的修改不可用了
                        //ArrayList<HashMap<String, String>> result = RuoKuaiApi.getCodeResultFrom1104(jsonObject1.toString()); //平台解析的结果
                        //accountRegisterService.identifyingCodeVerify(okHttpClient, deviceEntity, errorCode, codeId, result);

                    }
                }
                String code = emailGetter.getIdentCode(phoneEntity,okHttpClient);
                //等待验证码
                dyUserEntity.setCaptcha(code); //加入注册的验证码
                dyUserEntity = accountRegisterService.smsLogin310(okHttpClient, phoneEntity, deviceEntity);

                //如果成功存到数据库
//            dyUserRepository.save(dyUserEntity);
                Thread.sleep(1000);
                //先调用第一个，然后延迟一会儿
                accountRegisterService.whetherHasSet(okHttpClient, dyUserEntity);

                //调用下面两个，发送验证码
                accountRegisterService.passwordCheck(okHttpClient, dyUserEntity);
                accountRegisterService.passwordModifySendCode(okHttpClient, dyUserEntity, phoneEntity);

                //发送下面两个请求，记得验证码加进去
                accountRegisterService.passwordCheck(okHttpClient, dyUserEntity);
                accountRegisterService.passwordChange(okHttpClient, dyUserEntity, phoneEntity);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }else {
            logger.info("---------------并没能取到号--------------");
        }

    }

    public void successThumbUp(OrderEntity orderEntity,DyUserEntity dyUserEntity){

        synchronized (orderEntity){
            int num = orderEntity.getOperationCount()-1;
            orderEntity.setOperationCount(num);
            if(num%100==0){
                //orderEntity.setStatus("0");
                orderEntityRepository.save(orderEntity);
                NineFiveOrderPlatform nineFiveOrderPlatform = null;
                try {
                    nineFiveOrderPlatform = NineFiveOrderPlatform.getInstrance("点赞");
                } catch (NullTypeException e) {
                    e.printStackTrace();
                }
                nineFiveOrderPlatform.changeOrderCount(orderEntity);
                if(num ==0){
                    orderEntity.setStatus("0");
                    synchronized (MessionThread.thumbUpQueue){
                        MessionThread.thumbUpQueue.remove(orderEntity);
                    }
                    nineFiveOrderPlatform.getOrderFinished(orderEntity);
                }
            }
        }
        int num = dyUserEntity.getDiggCount()+1;
        dyUserEntity.setDiggCount(num);
    }

    public static OkHttpClient getOkhttpForWork(){
        HostIPPo hostIPPo = null;
        //logger.info("获取ip");
        OkHttpClient okHttpClient;
        try {
            hostIPPo = MessionThread.hostIpQuene.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        okHttpClient = new OkHttpClient.Builder()
                .readTimeout(60, TimeUnit.SECONDS)//设置读取超时时间
                .writeTimeout(60, TimeUnit.SECONDS)//设置写的超时时间
                .connectTimeout(60,TimeUnit.SECONDS)//设置连接超时时间
                .proxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(hostIPPo.host, hostIPPo.port)))
                .build();
        //logger.info(Thread.currentThread()+" 线程运行");
        return okHttpClient;
    }

}
