package com.space.dyrev.apisupport.ruokuaiPlatform;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @program: protocol
 * @description: 若快平台关于1104验证码解析结果的存储类
 * @author: gaoxiang
 * @create: 2018-11-20 20:18
 **/
public class RukuaiPo {

    //存储结果的属性名称
    ArrayList<HashMap<String,String>> posPlace = new ArrayList<>();
    //识别码，用于对图片结果报错,告诉他们本次图片识别错误;
    public String picID = "";

    public ArrayList<HashMap<String, String>> getPosPlace() {
        return posPlace;
    }

    public void setPosPlace(ArrayList<HashMap<String, String>> posPlace) {
        this.posPlace = posPlace;
    }

    public String getPicID() {
        return picID;
    }

    public void setPicID(String picID) {
        this.picID = picID;
    }

}
