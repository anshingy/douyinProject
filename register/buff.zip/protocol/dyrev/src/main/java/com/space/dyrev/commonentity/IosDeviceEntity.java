package com.space.dyrev.commonentity;

import com.space.dyrev.request.iosrequest.ioscommonparams.IOSParamsCreator;

import javax.persistence.*;

/**
 *           .]]]]]]`.            .]]]]`           .]]]]].            .,]]]]]`        .]]]]`
 *         ,@@@@@@@@@@^    @@@@./@@@@@@@@@^    =@@@@@@@@@@@@.      ]@@@@@@@@@@@^   ,@@@@@@@@@@`
 *        .@@@@`    .[`    @@@@@@@[`..[@@@@@   =@/`    .\@@@@    ,@@@@@[.    ,[.  /@@@/.  .\@@@\
 *        =@@@\            @@@@/.       @@@@^            @@@@   ,@@@@/           /@@@^      =@@@^
 *         \@@@@@]`        @@@@.        =@@@@        ...]@@@@   =@@@@           .@@@@]]]]]]]]@@@@
 *          ,\@@@@@@@]     @@@@.        .@@@@   ,@@@@@@@@@@@@   @@@@^           =@@@@@@@@@@@@@@@@
 *              ,\@@@@@`   @@@@.        =@@@@ ,@@@@/.    @@@@   =@@@@           .@@@@
 *                 =@@@@   @@@@.        /@@@^ @@@@.      @@@@   ,@@@@^           \@@@\
 *        =].      =@@@/   @@@@@]     ./@@@/  @@@@\    ,/@@@@`   ,@@@@@`      ,`  \@@@@`       .`
 *        =@@@@@@@@@@@/    @@@@@@@@@@@@@@@`   .@@@@@@@@@@/@@@@@^  .\@@@@@@@@@@@^   ,@@@@@@@@@@@@@
 *         ,[\@@@@@[`      @@@@..[\@@@@[.       .[@@@@[.  ,\@@@[     ,[@@@@@/[`.      ,[@@@@@/[`.
 *                         @@@@.
 *                         @@@@.
 *                         @@@@.
 *                                                                                             @ClassName IosDeviceEntity
 *                                                                                             @Author: space
 *                                                                                             @Description TODO 
 *                                                                                             @Date: 2018/10/11 23:29
 **/
 @Entity
 @Table(name = "t_ios_device")
public class IosDeviceEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    // 运营商标识
    private String ac;

    // App Store
    private String channel;

    // iphone
    private String devicePlatform;

    // 12.0.1
    private String osVersion;

    // 1944cda251 6eb4c0d68f e759086007 2b7dbb8e26
    private String openudid;

    private String deviceType;

    private String screenWidth;

    private String vid;

    // 46000 46009
    private String mccMnc;

    // WIFI
    private String access;

    // 669CAB57-A893-4C64-A295-49A65F9A2AD7
    private String idfa;

    private String resolution;

    private String dId;

    private String iId;

    public String getIdfa() {
        return idfa;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public void setIdfa(String idfa) {
        this.idfa = idfa;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAc() {
        return ac;
    }

    public void setAc(String ac) {
        this.ac = ac;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getDevicePlatform() {
        return devicePlatform;
    }

    public void setDevicePlatform(String devicePlatform) {
        this.devicePlatform = devicePlatform;
    }

    public String getOsVersion() {
        return osVersion;
    }

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    public String getOpenudid() {
        return openudid;
    }

    public void setOpenudid(String openudid) {
        this.openudid = openudid;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getScreenWidth() {
        return screenWidth;
    }

    public void setScreenWidth(String screenWidth) {
        this.screenWidth = screenWidth;
    }

    public String getVid() {
        return vid;
    }

    public void setVid(String vid) {
        this.vid = vid;
    }

    public String getMccMnc() {
        return mccMnc;
    }

    public void setMccMnc(String mccMnc) {
        this.mccMnc = mccMnc;
    }

    public String getAccess() {
        return access;
    }

    public void setAccess(String access) {
        this.access = access;
    }

    public String getdId() {
        return dId;
    }

    public void setdId(String dId) {
        this.dId = dId;
    }

    public String getiId() {
        return iId;
    }

    public void setiId(String iId) {
        this.iId = iId;
    }

    public static IosDeviceEntity createIosDevice() {
        IosDeviceEntity device = new IosDeviceEntity();
        device.setAc(IOSParamsCreator.createAc());
        device.setChannel(IOSParamsCreator.createChannel());
        device.setDevicePlatform("iphone");
        device.setDeviceType(IOSParamsCreator.createDeviceType());
        device.setIdfa(IOSParamsCreator.createIdfaAndVendorId());
        device.setMccMnc(IOSParamsCreator.createMccMnc());
        device.setOpenudid(IOSParamsCreator.createOpenudid());
        device.setOsVersion(IOSParamsCreator.createOsVersion());
        device.setScreenWidth(IOSParamsCreator.createScreenWidth());
        device.setVid(IOSParamsCreator.createIdfaAndVendorId());
        device.setAccess(IOSParamsCreator.createAccess());
        device.setResolution("750*1334");
        return device;
    }

    @Override
    public String toString() {
        return "IosDeviceEntity{" +
            "id=" + id +
            ", ac='" + ac + '\'' +
            ", channel='" + channel + '\'' +
            ", devicePlatform='" + devicePlatform + '\'' +
            ", osVersion='" + osVersion + '\'' +
            ", openudid='" + openudid + '\'' +
            ", deviceType='" + deviceType + '\'' +
            ", screenWidth='" + screenWidth + '\'' +
            ", vid='" + vid + '\'' +
            ", mccMnc='" + mccMnc + '\'' +
            ", access='" + access + '\'' +
            ", idfa='" + idfa + '\'' +
            ", dId='" + dId + '\'' +
            ", iId='" + iId + '\'' +
            '}';
    }

    public static void main(String[] args) {
        IosDeviceEntity deviceEntity = IosDeviceEntity.createIosDevice();
        System.out.println(deviceEntity);
    }
}
