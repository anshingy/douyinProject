package com.space.dyrev.apisupport.codeapi;

import com.space.dyrev.commonentity.PhoneEntity;
import okhttp3.OkHttpClient;

import java.io.IOException;

/**
 * @program: protocol
 * @description: 号码平台接口声明
 * @author: gaoxiang
 * @create: 2018-11-16 22:07
 **/
public interface PhoneCodeApi {

    //DaShiZiCodeApi getInstrance();

    //void loginIT(String user,String password);

    PhoneEntity getPhoneNumber(OkHttpClient okhttpclient)throws Exception ;

    PhoneEntity getPhoneNumber(String phoneNum, OkHttpClient okhttpclient) throws Exception ;

    String getIdentCode(PhoneEntity phoneEntity, OkHttpClient okhttpclient) throws IOException;


}
