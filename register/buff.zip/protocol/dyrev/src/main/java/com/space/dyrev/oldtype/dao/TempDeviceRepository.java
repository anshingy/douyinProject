package com.space.dyrev.oldtype.dao;


import com.space.dyrev.oldtype.entity.TempDevice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface TempDeviceRepository extends JpaRepository<TempDevice, Integer>, JpaSpecificationExecutor<TempDevice> {



}
