package com.space.dyrev.enumeration;

/**
 * 控制版本的枚举类
 */
public enum VersionEnum {
    V270,
    V310,
    V320
}
