package com.space.dyrev.paintplatform;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * @program: protocol
 * @description: 下载图片实现类
 * @author: gaoxiang
 * @create: 2018-11-16 21:45
 **/
public class DownImage {

    public static String localOneImageUrl = "picture/bufferOne.jpg";
    public static String oneFileUrl = DownImage.class.getClassLoader().getResource(localOneImageUrl).getPath();
    public static String localTwoImageUrl = "picture/bufferTwo.jpg";
    public static String twoFileUrl = DownImage.class.getClassLoader().getResource(localTwoImageUrl).getPath();

    public static DownImage downImage = new DownImage();

    public static DownImage getInstrance() {
        return downImage;
    }

    public void getImageFromUrl(String destUrl,int turn) {
        FileOutputStream fos = null;
        BufferedInputStream bis = null;
        HttpURLConnection httpUrl = null;
        URL url = null;
        int BUFFER_SIZE = 1024;
        byte[] buf = new byte[BUFFER_SIZE];
        int size = 0;
        try {
            url = new URL(destUrl);
            httpUrl = (HttpURLConnection) url.openConnection();
            httpUrl.connect();
            bis = new BufferedInputStream(httpUrl.getInputStream());
            //"D:\\protocol\\dyrev\\src\\main\\resources\\picture\\buffer.jpg");
            //
            //System.out.println(fileUrl);
            if(turn ==1){
                fos = new FileOutputStream(oneFileUrl);
            }else if(turn ==2){
                fos = new FileOutputStream(twoFileUrl);
            }
            while ((size = bis.read(buf)) != -1) {
                fos.write(buf, 0, size);
            }
            fos.flush();
        } catch (IOException e) {

        } catch (ClassCastException e) {
        } finally {
            try {
                fos.close();
                bis.close();
                httpUrl.disconnect();
            } catch (IOException e) {
            } catch (NullPointerException e) {
            }
        }
    }

    public static void main(String[]args){
        DownImage downImage = DownImage.getInstrance();
        //downImage.getImageFromUrl("http://sf3-dycdn-tos.pstatp.com/obj/security-captcha/text_c18ae807ec8cd21e2b72537da05cead7fcd05a2b_2_1.jpg");

        //downImage.getImageFromUrl("http://sf3-dycdn-tos.pstatp.com/obj/security-captcha/text_c18ae807ec8cd21e2b72537da05cead7fcd05a2b_1_1.jpg");
        }
}
