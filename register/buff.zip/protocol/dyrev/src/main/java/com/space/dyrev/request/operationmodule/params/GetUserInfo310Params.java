package com.space.dyrev.request.operationmodule.params;

import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.request.commonparams.CommonParams;
import com.space.dyrev.util.httputil.CookieTool;

import java.util.HashMap;
import java.util.Map;

/**
 * @program: dyrev
 * @description: 310版本获取用户信息
 * @author: Mr.Jia
 * @create: 2018-11-13 14:37
 **/
public class GetUserInfo310Params {

    private static final String HOST = "api.amemv.com";

    private static final String FUNC = "/aweme/v1/user/?";

    /**
     * 构造url
     * @param dyUserEntity
     * @return
     */
    public static String constructUrl(DyUserEntity dyUserEntity, String userId) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();
        String url = "https://"+HOST+FUNC+"user_id="+userId+"&ts="+System.currentTimeMillis()/1000+"&js_sdk_version=1.2.2&app_type=normal&os_api="+CommonParams.OS_API+"device_type="+deviceEntity.getDeviceType()+"&device_platform=android&ssmix=a&iid="+deviceEntity.getInstallId()+"&manifest_version_code=310&dpi="+deviceEntity.getDpi()+"&uuid="+deviceEntity.getUuid()+"&version_code=310&app_name=aweme&version_name=3.1.0&openudid="+deviceEntity.getOpenudid()+"&device_id="+deviceEntity.getDeviceId()+"&resolution="+deviceEntity.getResolution()+"&os_version="+CommonParams.OS_VERSION+"&language=zh&device_brand="+deviceEntity.getDeviceBrand()+"&ac=wifi&update_version_code=3102&aid=1128&channel=meizu&_rticket="+System.currentTimeMillis()+"&as=a1iosdfgh&cp=androide1";

        return url;
    }

    /**
     * 构造header
     * @param dyUserEntity
     * @return
     */
    public static Map constructHeader(DyUserEntity dyUserEntity) {

        Map<String, String> header = new HashMap<String, String>();
        header.put("Host","api.amemv.com");
        header.put("Connection","keep-alive");
        header.put("Accept-Encoding","gzip");
        header.put("Cookie", CookieTool.getCookieFromDevAndAcc(dyUserEntity.getDevice(), dyUserEntity));
        header.put("X-SS-REQ-TICKET", String.valueOf(System.currentTimeMillis()));
        header.put("sdk-version","1");
        header.put("X-Tt-Token","");
        header.put("X-SS-TC","0");
        header.put("User-Agent",CommonParams.getUserAgent(dyUserEntity.getDevice().getDeviceType()));

        return header;
    }
}
