package com.space.dyrev.request.accountregistermodule.params;

import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.commonentity.PhoneEntity;
import com.space.dyrev.request.commonparams.CommonParams;
import com.space.dyrev.util.httputil.CookieTool;

import java.util.HashMap;
import java.util.Map;

/**
 * @program: dyrev
 * @description: 310版本修改密码请求需要参数构造类
 * @author: Mr.Jia
 * @create: 2018-11-15 00:05
 **/
public class PasswordModify310Params {

    private static final String HOST_HAS_SET = "is.snssdk.com";

    private static final String FUNC_HAS_SET = "/passport/password/has_set/?";

    private static final String HOST_CHECK = "is.snssdk.com";

    private static final String FUNC_CHECK = "/passport/password/check/?";

    private static final String HOST_CHANGE = "is.snssdk.com";

    private static final String FUNC_CHANGE = "/passport/password/change/?";

    private static final String HOST_SEND_CODE = "lf.snssdk.com";

    private static final String FUNC_SEND_CODE = "/passport/mobile/send_code/v1/?";

    /**
     * 构造has_set请求的url头
     * @param dyUserEntity
     * @return
     */
    public static String constructHasSetUrl (DyUserEntity dyUserEntity) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();
        String url = "https://"+HOST_HAS_SET+FUNC_HAS_SET+"ts="+System.currentTimeMillis()/1000+"&js_sdk_version=1.2.2&app_type=normal&os_api="+ CommonParams.OS_API+"&device_type="+deviceEntity.getDeviceType()+"&device_platform=android&ssmix=a&iid="+deviceEntity.getInstallId()+"&manifest_version_code=310&dpi="+deviceEntity.getDpi()+"&uuid="+deviceEntity.getUuid()+"&version_code=310&app_name=aweme&version_name=3.1.0&openudid="+deviceEntity.getOpenudid()+"&device_id="+deviceEntity.getDeviceId()+"&resolution="+deviceEntity.getResolution()+"&os_version="+CommonParams.OS_VERSION+"&language=zh&device_brand="+deviceEntity.getDeviceBrand()+"&ac=wifi&update_version_code=3102&aid=1128&channel=meizu&_rticket="+System.currentTimeMillis()+"&as=a1iosdfgh&cp=androide1";

        return url;
    }

    /**
     * has_set请求构造header
     * @return
     */
    public static Map constructHasSetHeader(DyUserEntity dyUserEntity) {

        Map<String, String> header = new HashMap<String, String>();
        header.put("Host",HOST_HAS_SET);
        header.put("Connection","keep-alive");
        header.put("Cookie", CookieTool.getCookieFromDevAndAcc(dyUserEntity.getDevice(), dyUserEntity));
        header.put("Accept-Encoding","gzip");
        header.put("X-SS-REQ-TICKET",String.valueOf(System.currentTimeMillis()));
        header.put("X-SS-TC","0");
        header.put("X-Tt-Token","");
        header.put("sdk-version","1");
        header.put("User-Agent","com.ss.android.ugc.aweme/310 (Linux; U; Android 7.1.2; zh_CN; "+dyUserEntity.getDevice().getDeviceType()+"; Build/N2G47H; Cronet/58.0.2991.0)");

        return header;
    }

    /**
     * 构造Check请求的url头
     * @param dyUserEntity
     * @return
     */
    public static String constructCheckUrl (DyUserEntity dyUserEntity) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();
        String url = "https://"+HOST_CHECK+FUNC_CHECK+"os_api="+CommonParams.OS_API+"&device_type="+deviceEntity.getDeviceType()+"&device_platform=android&ssmix=a&iid="+deviceEntity.getInstallId()+"&manifest_version_code=310&dpi="+deviceEntity.getDpi()+"&uuid="+deviceEntity.getUuid()+"&version_code=310&app_name=aweme&version_name=3.1.0&openudid="+deviceEntity.getOpenudid()+"&device_id="+deviceEntity.getDeviceId()+"&resolution="+deviceEntity.getResolution()+"&os_version="+CommonParams.OS_VERSION+"&language=zh&device_brand="+deviceEntity.getDeviceBrand()+"&ac=wifi&update_version_code=3102&aid=1128&channel=meizu&_rticket="+System.currentTimeMillis()+"&ts="+System.currentTimeMillis()/1000+"&js_sdk_version=1.2.2&as=a1iosdfgh&cp=androide1";

        return url;
    }

    /**
     * Check请求构造header
     * @return
     */
    public static Map constructCheckHeader(DyUserEntity dyUserEntity) {

        Map<String, String> header = new HashMap<String, String>();
        header.put("Host",HOST_CHECK);
        header.put("Connection","keep-alive");
        header.put("Content-Length","500");
        header.put("Cookie", CookieTool.getCookieFromDevAndAcc(dyUserEntity.getDevice(), dyUserEntity));
        header.put("Accept-Encoding","gzip");
        header.put("X-SS-TC","0");
        header.put("X-Tt-Token","");
        header.put("sdk-version","1");
        header.put("X-SS-REQ-TICKET",String.valueOf(System.currentTimeMillis()));
        header.put("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
        header.put("User-Agent","com.ss.android.ugc.aweme/310 (Linux; U; Android 7.1.2; zh_CN; "+dyUserEntity.getDevice().getDeviceType()+"; Build/N2G47H; Cronet/58.0.2991.0)");

        return header;
    }

    /**
     * Check请求构造的body
     * @param dyUserEntity
     * @return
     */
    public static Map constructCheckBody(DyUserEntity dyUserEntity) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();
        Map<String, String> body = new HashMap<String, String>();
        body.put("device_type",deviceEntity.getDeviceType());
        body.put("mix_mode","1");
        body.put("retry_type","no_retry");
        body.put("os_api",CommonParams.OS_API);
        body.put("device_platform","android");
        body.put("ssmix","a");
        body.put("iid",deviceEntity.getInstallId());
        body.put("manifest_version_code","310");
        body.put("dpi",deviceEntity.getDpi());
        body.put("password","647661343736313033");
        body.put("uuid",deviceEntity.getUuid());
        body.put("version_code","310");
        body.put("app_name","aweme");
        body.put("version_name","3.1.0");
        body.put("openudid",deviceEntity.getOpenudid());
        body.put("device_id",deviceEntity.getDeviceId());
        body.put("resolution",deviceEntity.getResolution());
        body.put("os_version",CommonParams.OS_VERSION);
        body.put("language","zh");
        body.put("device_brand",deviceEntity.getDeviceBrand());
        body.put("ac","wifi");
        body.put("update_version_code","3102");
        body.put("aid","1128");
        body.put("channel","meizu");
        body.put("_rticket", String.valueOf(System.currentTimeMillis()));

        return body;
    }

    /**
     * 构造change请求的url头
     * @param dyUserEntity
     * @return
     */
    public static String constructChangeUrl (DyUserEntity dyUserEntity) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();
        String url = "https://"+HOST_CHANGE+FUNC_CHANGE+"os_api="+CommonParams.OS_API+"&device_type="+deviceEntity.getDeviceType()+"&device_platform=android&ssmix=a&iid="+deviceEntity.getInstallId()+"&manifest_version_code=310&dpi="+deviceEntity.getDpi()+"&uuid="+deviceEntity.getUuid()+"&version_code=310&app_name=aweme&version_name=3.1.0&openudid="+deviceEntity.getOpenudid()+"&device_id="+deviceEntity.getDeviceId()+"&resolution="+deviceEntity.getResolution()+"&os_version="+CommonParams.OS_VERSION+"&language=zh&device_brand="+deviceEntity.getDeviceBrand()+"&ac=wifi&update_version_code=3102&aid=1128&channel=meizu&_rticket="+System.currentTimeMillis()+"&ts="+System.currentTimeMillis()/1000+"&js_sdk_version=1.2.2&as=a1iosdfgh&cp=androide1";

        return url;
    }

    /**
     * Change请求构造header
     * @return
     */
    public static Map constructChangeHeader(DyUserEntity dyUserEntity) {

        Map<String, String> header = new HashMap<String, String>();
        header.put("Host",HOST_CHANGE);
        header.put("Connection","keep-alive");
        header.put("Content-Length","500");
        header.put("Cookie", CookieTool.getCookieFromDevAndAcc(dyUserEntity.getDevice(), dyUserEntity));
        header.put("Accept-Encoding","gzip");
        header.put("X-SS-REQ-TICKET",String.valueOf(System.currentTimeMillis()));
        header.put("X-SS-TC","0");
        header.put("X-Tt-Token","");
        header.put("sdk-version","1");
        header.put("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
        header.put("User-Agent","com.ss.android.ugc.aweme/310 (Linux; U; Android 7.1.2; zh_CN; "+dyUserEntity.getDevice().getDeviceType()+"; Build/N2G47H; Cronet/58.0.2991.0)");

        return header;
    }

    /**
     * Change请求构造的body
     * @param dyUserEntity
     * @return
     */
    public static Map constructChangeBody(DyUserEntity dyUserEntity, PhoneEntity phoneEntity) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();
        Map<String, String> body = new HashMap<String, String>();
        body.put("os_api",CommonParams.OS_API);
        body.put("device_type",deviceEntity.getDeviceType());
        body.put("ssmix","a");
        body.put("manifest_version_code","310");
        body.put("dpi",deviceEntity.getDpi());
        body.put("uuid",deviceEntity.getUuid());
        body.put("app_name","aweme");
        body.put("version_name","3.1.0");
        body.put("retry_type","no_retry");
        body.put("ac","wifi");
        body.put("channel","meizu");
        body.put("update_version_code","3102");
        body.put("_rticket", String.valueOf(System.currentTimeMillis()));
        body.put("device_platform","android");
        body.put("password","647661343736313033");
        body.put("iid",deviceEntity.getInstallId());
        body.put("mix_mode","1");
        body.put("code",SendCode310Params.num_change(phoneEntity.getCode()));
        body.put("version_code","310");
        body.put("captcha",dyUserEntity.getCaptcha());
        body.put("openudid",deviceEntity.getOpenudid());
        body.put("device_id",deviceEntity.getDeviceId());
        body.put("resolution",deviceEntity.getResolution());
        body.put("os_version",CommonParams.OS_VERSION);
        body.put("language","zh");
        body.put("device_brand",deviceEntity.getDeviceBrand());
        body.put("aid","1128");

        return body;
    }

    /**
     * 构造SendCode请求的url头
     * @param dyUserEntity
     * @return
     */
    public static String constructSendCodeUrl (DyUserEntity dyUserEntity) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();
        String url = "https://"+HOST_SEND_CODE+FUNC_SEND_CODE+"os_api="+CommonParams.OS_API+"&device_type="+deviceEntity.getDeviceType()+"&device_platform=android&ssmix=a&iid="+deviceEntity.getInstallId()+"&manifest_version_code=310&dpi="+deviceEntity.getDpi()+"&uuid="+deviceEntity.getUuid()+"&version_code=310&app_name=aweme&version_name=3.1.0&openudid="+deviceEntity.getOpenudid()+"&device_id="+deviceEntity.getDeviceId()+"&resolution="+deviceEntity.getResolution()+"&os_version="+CommonParams.OS_VERSION+"&language=zh&device_brand="+deviceEntity.getDeviceBrand()+"&ac=wifi&update_version_code=3102&aid=1128&channel=meizu&_rticket="+System.currentTimeMillis()+"&ts="+System.currentTimeMillis()/1000+"&js_sdk_version=1.2.2&as=a1iosdfgh&cp=androide1";

        return url;
    }

    /**
     * SendCode请求构造header
     * @return
     */
    public static Map constructSendCodeHeader(DyUserEntity dyUserEntity) {

        Map<String, String> header = new HashMap<String, String>();
        header.put("Host",HOST_SEND_CODE);
        header.put("Connection","keep-alive");
        header.put("Content-Length","500");
        header.put("Cookie", CookieTool.getCookieFromDevAndAcc(dyUserEntity.getDevice(), dyUserEntity));
        header.put("Accept-Encoding","gzip");
        header.put("X-SS-REQ-TICKET",String.valueOf(System.currentTimeMillis()));
        header.put("X-SS-TC","0");
        header.put("sdk-version","1");
        header.put("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
        header.put("User-Agent","com.ss.android.ugc.aweme/310 (Linux; U; Android 7.1.2; zh_CN; "+dyUserEntity.getDevice().getDeviceType()+"; Build/N2G47H; Cronet/58.0.2991.0)");

        return header;
    }

    /**
     * SendCode请求构造的body
     * @param dyUserEntity
     * @return
     */
    public static Map constructSendCodeBody(DyUserEntity dyUserEntity, PhoneEntity phoneEntity) {

        DeviceEntity deviceEntity = dyUserEntity.getDevice();
        Map<String, String> body = new HashMap<String, String>();
        body.put("device_type",deviceEntity.getDeviceType());
        body.put("type","3436");
        body.put("mix_mode","1");
        body.put("mobile",SendCode310Params.num_change(phoneEntity.getArea().getAreaNum() + phoneEntity.getPhoneNum()));
        body.put("retry_type","no_retry");
        body.put("os_api",CommonParams.OS_API);
        body.put("device_platform","android");
        body.put("ssmix","a");
        body.put("iid",deviceEntity.getInstallId());
        body.put("manifest_version_code","310");
        body.put("dpi",deviceEntity.getDpi());
        body.put("auto_read","0");
        body.put("uuid",deviceEntity.getUuid());
        body.put("version_code","310");
        body.put("app_name","aweme");
        body.put("version_name","3.1.0");
        body.put("openudid",deviceEntity.getOpenudid());
        body.put("device_id",deviceEntity.getDeviceId());
        body.put("resolution",deviceEntity.getResolution());
        body.put("os_version",CommonParams.OS_VERSION);
        body.put("language","zh");
        body.put("device_brand",deviceEntity.getDeviceBrand());
        body.put("ac","wifi");
        body.put("update_version_code","3102");
        body.put("aid","1128");
        body.put("channel","meizu");
        body.put("_rticket", String.valueOf(System.currentTimeMillis()));

        return body;
    }
}
