package com.space.dyrev.paintplatform;

import okhttp3.*;
import sun.misc.BASE64Decoder;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;

/**
 * @program: protocol
 * @description: 画板位置
 * @author: gaoxiang
 * @create: 2018-11-15 23:39
 **/
public class PictureBuilder{

    public static String localImageUrl = "picture/result.png";
    public static ImageIcon backGroundImage = new ImageIcon(PictureBuilder.class.getClassLoader().getResource("picture/background.png"));
    public static int picOne_X = 268,picOne_y = 150;
    public static int picTwo_x =72, picTwo_y = 36;
    public static DownImage downImage =DownImage.getInstrance();
    private static OkHttpClient okHttpClient = new OkHttpClient();
    public static PictureBuilder pictureBuilder = new PictureBuilder();

    public static PictureBuilder getInstance(){
        return pictureBuilder;
    }

    private PictureBuilder(){

    }

    /**
     * 对验证码进行加工的方法，传入两个url就行了
     * @param bi 画布对象
     * @param urlOne 第一个图片的url
     * @param urlTwo 第二个图片的url
     * @return 返回加工完的图片画布
     */
    public BufferedImage writeImage(BufferedImage bi,String urlOne,String urlTwo){
        ImageIcon imageIconOne = null;
        ImageIcon imageIconTwo = null;

        downImage.getImageFromUrl(urlOne,1);
        imageIconOne = new ImageIcon(DownImage.oneFileUrl);
        System.out.println(imageIconOne.getIconHeight());
        downImage.getImageFromUrl(urlTwo,2);
        imageIconTwo = new ImageIcon(DownImage.twoFileUrl);
        picTwo_x = imageIconTwo.getIconWidth();
        System.out.println(imageIconTwo.getIconHeight());
        Graphics graphics = bi.getGraphics();
        graphics.drawImage(backGroundImage.getImage(),0,0,picOne_X-picTwo_x,picTwo_y,null);
        graphics.drawImage(imageIconOne.getImage(),0,picTwo_y,picOne_X,picOne_y,null);
        graphics.drawImage(imageIconTwo.getImage(),picOne_X-picTwo_x,0,picTwo_x,picTwo_y,null);
        return bi;
    }

    /**
     *
     * @param bi BufferedImage绘制图片画布
     * @return true 标识存储结果
     */
    public boolean writeImage(BufferedImage bi) {
        String fileUrl = this.getClass().getClassLoader().getResource(localImageUrl).getPath();
        File file = new File(fileUrl);
        try {
            if(file.exists()) {
                file.delete();
                file.createNewFile();
            }
        }catch(IOException e) {
            e.printStackTrace();
        }
        boolean val = false;
        try {
            val = ImageIO.write(bi, "jpg", file);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return val;
    }

    public static void main(String[]args){
        BufferedImage bi = new BufferedImage(268, 186, BufferedImage.TYPE_INT_BGR);
        PictureBuilder mainPanel = PictureBuilder.getInstance();
        bi = mainPanel.writeImage(bi,"http://sf3-dycdn-tos.pstatp.com/obj/security-captcha/text_bd9622617fb7055b754c01ab7fc7360644c4e464_1_1.jpg","http://sf3-dycdn-tos.pstatp.com/obj/security-captcha/text_bd9622617fb7055b754c01ab7fc7360644c4e464_2_1.jpg");
        mainPanel.writeImage(bi);
        System.out.println("绘图成功");
    }

}
