package com.space.dyrev.request.iosrequest.deviceregistermodule.service.impl;

import com.space.dyrev.commonentity.IosDeviceEntity;
import com.space.dyrev.enumeration.VersionEnum;
import com.space.dyrev.request.iosrequest.deviceregistermodule.service.IosDeviceRegisterService;
import okhttp3.OkHttpClient;
import org.springframework.stereotype.Service;

/**
 *           .]]]]]]`.            .]]]]`           .]]]]].            .,]]]]]`        .]]]]`
 *         ,@@@@@@@@@@^    @@@@./@@@@@@@@@^    =@@@@@@@@@@@@.      ]@@@@@@@@@@@^   ,@@@@@@@@@@`
 *        .@@@@`    .[`    @@@@@@@[`..[@@@@@   =@/`    .\@@@@    ,@@@@@[.    ,[.  /@@@/.  .\@@@\
 *        =@@@\            @@@@/.       @@@@^            @@@@   ,@@@@/           /@@@^      =@@@^
 *         \@@@@@]`        @@@@.        =@@@@        ...]@@@@   =@@@@           .@@@@]]]]]]]]@@@@
 *          ,\@@@@@@@]     @@@@.        .@@@@   ,@@@@@@@@@@@@   @@@@^           =@@@@@@@@@@@@@@@@
 *              ,\@@@@@`   @@@@.        =@@@@ ,@@@@/.    @@@@   =@@@@           .@@@@
 *                 =@@@@   @@@@.        /@@@^ @@@@.      @@@@   ,@@@@^           \@@@\
 *        =].      =@@@/   @@@@@]     ./@@@/  @@@@\    ,/@@@@`   ,@@@@@`      ,`  \@@@@`       .`
 *        =@@@@@@@@@@@/    @@@@@@@@@@@@@@@`   .@@@@@@@@@@/@@@@@^  .\@@@@@@@@@@@^   ,@@@@@@@@@@@@@
 *         ,[\@@@@@[`      @@@@..[\@@@@[.       .[@@@@[.  ,\@@@[     ,[@@@@@/[`.      ,[@@@@@/[`.
 *                         @@@@.
 *                         @@@@.
 *                         @@@@.
 *                                                                                             @ClassName IosDeviceRegisterServiceImpl
 *                                                                                             @Author: space
 *                                                                                             @Description IOS设备注册
 *                                                                                             @Date: 2018/10/11 23:29
 **/
@Service("iosDeviceRegister")
public class IosDeviceRegisterServiceImpl implements IosDeviceRegisterService {


    @Override
    public IosDeviceEntity deviceRegister(OkHttpClient okHttpClient, IosDeviceEntity iosDeviceEntity, VersionEnum versionEnum) {

        return null;
    }
}
