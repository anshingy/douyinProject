package com.space.dyrev.request.accountregistermodule.params;

import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.PhoneEntity;
import com.space.dyrev.encrypt.PhoneNumberEncrypt;
import com.space.dyrev.request.commonparams.CommonParams;
import com.space.dyrev.request.commonparams.CommonUrlPart;
import com.space.dyrev.util.httputil.CookieTool;

import java.util.HashMap;
import java.util.Map;

/**
 * @program: dyrev
 * @description: 310版本验证码登录
 * @author: Mr.Jia
 * @create: 2018-11-10 22:09
 **/
public class SmsLogin310Params {

    private static final String HOST = "is.snssdk.com";

    private static final String FUNC = "/passport/mobile/sms_login/?";

    /**
     * 构造请求url
     * @param deviceEntity
     * @return
     */
    public static String constructUrl(DeviceEntity deviceEntity) {

        String url = "http://"+HOST+FUNC+"os_api=25&device_type="+deviceEntity.getDeviceType()+"&device_platform=android&ssmix=a&iid="+ deviceEntity.getInstallId()+"&manifest_version_code=310&dpi="+deviceEntity.getDpi()+"&uuid="+deviceEntity.getUuid()+"&version_code=310&app_name=aweme&version_name=3.1.0&openudid="+deviceEntity.getOpenudid()+"&device_id="+deviceEntity.getDeviceId()+"&resolution="+deviceEntity.getResolution()+"&os_version=7.1.2&language=zh&device_brand="+deviceEntity.getDeviceBrand()+"&ac=wifi&update_version_code=3102&aid=1128&channel=meizu&_rticket="+System.currentTimeMillis()+"&ts="+System.currentTimeMillis()/1000+"&js_sdk_version=1.2.2&as=a1iosdfgh&cp=androide1";

        return url;
    }

    /**
     * 构造header
     * @param deviceEntity
     * @return
     */
    public static Map constructHeader(DeviceEntity deviceEntity) {

        Map<String, String> header = new HashMap<String, String>();
        header.put("Host","is.snssdk.com");
        header.put("Connection","keep-alive");
        header.put("Content-Length","500");
        header.put("Cookie","install_id="+deviceEntity.getInstallId()+";qh[360]=1");
        header.put("Accept-Encoding","gzip");
        header.put("X-SS-REQ-TICKET",String.valueOf(System.currentTimeMillis()));
        header.put("X-SS-TC","0");
        header.put("sdk-version","1");
        header.put("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
        header.put("User-Agent","com.ss.android.ugc.aweme/310 (Linux; U; Android 7.1.2; zh_CN; "+deviceEntity.getDeviceType()+"; Build/N2G47H; Cronet/58.0.2991.0)");

        return header;
    }


    /**
     * 构造body
     * @param deviceEntity
     * @param phoneEntity
     * @return
     */
    public static Map constructBody(DeviceEntity deviceEntity, PhoneEntity phoneEntity) {

        Map<String, String> body = new HashMap<String, String>();
        body.put("mix_mode","1");
        body.put("captcha","");
        body.put("code",PhoneNumberEncrypt.codeEncode(phoneEntity.getCode()));
        body.put("mobile",PhoneNumberEncrypt.encode(phoneEntity));
        body.put("retry_type","no_retry");
        body.put("os_api","25");
        body.put("device_type",deviceEntity.getDeviceType());
        body.put("evice_platform","android");
        body.put("ssmix","a");
        body.put("iid",deviceEntity.getInstallId());
        body.put("manifest_version_code","310");
        body.put("dpi",deviceEntity.getDpi());
        body.put("uuid",deviceEntity.getUuid());
        body.put("version_code","310");
        body.put("app_name","aweme");
        body.put("version_name","3.1.0");
        body.put("openudid",deviceEntity.getOpenudid());
        body.put("device_id",deviceEntity.getDeviceId());
        body.put("resolution",deviceEntity.getResolution());
        body.put("os_version","7.1.2");
        body.put("language","zh");
        body.put("device_brand",deviceEntity.getDeviceBrand());
        body.put("ac","wifi");
        body.put("update_version_code","3102");
        body.put("aid","1128");
        body.put("channel","meizu");
        body.put("_rticket", String.valueOf(System.currentTimeMillis()));

        return body;
    }

}
