package com.space.dyrev.oldtype.dao;


import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.oldtype.entity.TempUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.ArrayList;

public interface TempDyUserRepository extends JpaRepository<TempUser, Integer>, JpaSpecificationExecutor<TempUser> {

    @Query(value = "select * from t_dy_user2 where id > 1", nativeQuery = true)
    ArrayList<TempUser> getUserByLike(int id);
}
