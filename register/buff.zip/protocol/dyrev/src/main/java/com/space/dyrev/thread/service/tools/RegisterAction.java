package com.space.dyrev.thread.service.tools;

import com.alibaba.fastjson.JSONObject;
import com.mysql.cj.x.protobuf.Mysqlx;
import com.space.dyrev.apisupport.codeapi.PhoneCodeApi;
import com.space.dyrev.apisupport.email.EmailGetter;
import com.space.dyrev.apisupport.ruokuaiPlatform.RuoKuaiApi;
import com.space.dyrev.commonentity.DeviceEntity;
import com.space.dyrev.commonentity.DyUserEntity;
import com.space.dyrev.commonentity.PhoneEntity;
import com.space.dyrev.dao.DeviceRepository;
import com.space.dyrev.dao.DyUserRepository;
import com.space.dyrev.enumeration.PhoneArea;
import com.space.dyrev.request.accountregistermodule.service.AccountRegisterService;
import com.space.dyrev.request.deviceregistermodule.service.DeviceRegisterService;
import com.space.dyrev.request.operationmodule.service.OperationService;
import com.space.dyrev.thread.service.impl.UserThreadServiceImpl;
import com.space.dyrev.util.springutils.SpringUtil;
import okhttp3.OkHttpClient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * @program: protocol
 * @description: 注册活动实现类
 * @author: gaoxiang
 * @create: 2018-11-17 21:11
 **/
public class RegisterAction {

    public static PhoneCodeApi emailGetter = EmailGetter.getInstrance();
    public static OperationService operationService;
    public static DeviceRegisterService deviceRegisterService;
    public static AccountRegisterService accountRegisterService;
    public static DyUserRepository dyUserRepository;
    public static DeviceRepository deviceRepository;
    public boolean registerUserByV310(OkHttpClient okHttpClient){
        if(operationService==null){
            operationService = SpringUtil.getBean(OperationService.class);
            deviceRegisterService = SpringUtil.getBean(DeviceRegisterService.class);
            accountRegisterService = SpringUtil.getBean(AccountRegisterService.class);
            dyUserRepository = SpringUtil.getBean(DyUserRepository.class);
            deviceRepository = SpringUtil.getBean(DeviceRepository.class);

        }

        DyUserEntity dyUserEntity = new DyUserEntity();
        DeviceEntity deviceEntity = DeviceEntity.newDevice();
        deviceEntity = deviceRegisterService.deviceRegister310(okHttpClient, deviceEntity);
        deviceRepository.save(deviceEntity);
        dyUserEntity.setDevice(deviceEntity);

        //在平台取个号
        PhoneEntity phoneEntity = null;
        try {
            phoneEntity = emailGetter.getPhoneNumber(okHttpClient);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //选区号，现在是泰国
        phoneEntity.setArea(PhoneArea.TG);
        try {
            //返回jsonObject，高翔你自己判断是不是error和1104，取出来
            JSONObject json = accountRegisterService.sendCode310ForGX(okHttpClient, phoneEntity, deviceEntity);
            String status = json.getString("message");
            if(status.equals("error")){
                org.json.JSONObject jsonObject = new org.json.JSONObject(json.getJSONObject("data"));
                int kao = jsonObject.getInt("error_code");
                if(kao == 1104){
                    //如果1104发送请求获取验证码图片的两个url和验证码的id
                    JSONObject jsonObject1 = accountRegisterService.identifyingCodeGet(okHttpClient, deviceEntity, "errorCode");
                    JSONObject jsonObject2 = jsonObject1.getJSONObject("data");
                    //验证码确认,确认后会发送验证码
                    String codeId = jsonObject2.getString("id"); //上面这个请求拿到的
                    //修改平台后不在可用
                    //ArrayList<HashMap<String, String>> result = RuoKuaiApi.getCodeResultFrom1104(jsonObject1.toString()); //平台解析的结果
                    //accountRegisterService.identifyingCodeVerify(okHttpClient, deviceEntity, "errorCode", codeId, result);

                }
            }
            String code = emailGetter.getIdentCode(phoneEntity,okHttpClient);
            //等待验证码
            dyUserEntity.setCaptcha(code); //加入注册的验证码
            dyUserEntity = accountRegisterService.smsLogin310(okHttpClient, phoneEntity, deviceEntity);

            //如果成功存到数据库
            dyUserRepository.save(dyUserEntity);
            Thread.sleep(1000);
            //先调用第一个，然后延迟一会儿
            accountRegisterService.whetherHasSet(okHttpClient, dyUserEntity);

            //调用下面两个，发送验证码
            accountRegisterService.passwordCheck(okHttpClient, dyUserEntity);
            accountRegisterService.passwordModifySendCode(okHttpClient, dyUserEntity, phoneEntity);

            //发送下面两个请求，记得验证码加进去
            accountRegisterService.passwordCheck(okHttpClient, dyUserEntity);
            accountRegisterService.passwordChange(okHttpClient, dyUserEntity, phoneEntity);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

}
