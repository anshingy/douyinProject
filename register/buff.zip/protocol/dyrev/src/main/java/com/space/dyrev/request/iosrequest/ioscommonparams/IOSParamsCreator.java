package com.space.dyrev.request.iosrequest.ioscommonparams;

import com.space.dyrev.util.formatutil.ScaleTrans;

import java.util.Random;
import java.util.UUID;

/**
 *           .]]]]]]`.            .]]]]`           .]]]]].            .,]]]]]`        .]]]]`
 *         ,@@@@@@@@@@^    @@@@./@@@@@@@@@^    =@@@@@@@@@@@@.      ]@@@@@@@@@@@^   ,@@@@@@@@@@`
 *        .@@@@`    .[`    @@@@@@@[`..[@@@@@   =@/`    .\@@@@    ,@@@@@[.    ,[.  /@@@/.  .\@@@\
 *        =@@@\            @@@@/.       @@@@^            @@@@   ,@@@@/           /@@@^      =@@@^
 *         \@@@@@]`        @@@@.        =@@@@        ...]@@@@   =@@@@           .@@@@]]]]]]]]@@@@
 *          ,\@@@@@@@]     @@@@.        .@@@@   ,@@@@@@@@@@@@   @@@@^           =@@@@@@@@@@@@@@@@
 *              ,\@@@@@`   @@@@.        =@@@@ ,@@@@/.    @@@@   =@@@@           .@@@@
 *                 =@@@@   @@@@.        /@@@^ @@@@.      @@@@   ,@@@@^           \@@@\
 *        =].      =@@@/   @@@@@]     ./@@@/  @@@@\    ,/@@@@`   ,@@@@@`      ,`  \@@@@`       .`
 *        =@@@@@@@@@@@/    @@@@@@@@@@@@@@@`   .@@@@@@@@@@/@@@@@^  .\@@@@@@@@@@@^   ,@@@@@@@@@@@@@
 *         ,[\@@@@@[`      @@@@..[\@@@@[.       .[@@@@[.  ,\@@@[     ,[@@@@@/[`.      ,[@@@@@/[`.
 *                         @@@@.
 *                         @@@@.
 *                         @@@@.
 *                   @ClassName IOSParamsCreator
 *                   @Author: space
 *                   @Description IOS设备信息生成
 *                   @Date: 2018/11/12/012
 **/
public class IOSParamsCreator {

    /**
     *
     * @return 4g 3g
     */
    public static String createAc() {
        Random random = new Random();
        String [] ac = {"4G","3G"};
        return ac[random.nextInt(2)];
    }

    /**
     *
     * @return
     */
    public static String createChannel() {
        Random random = new Random();
        String [] ac = {"App Store"};
        return ac[random.nextInt(1)];
    }

    /**
     *
     * @return
     */
    public static String createOsVersion() {
        Random random = new Random();
        String [] ac = {"12.0.1", "10.0.2"};
        return ac[random.nextInt(ac.length)];
    }

    /**
     * 1944cda2516eb4c0d68fe7590860072b7dbb8e26
     * @return
     */
    public static String createOpenudid() {
        StringBuffer sb = new StringBuffer();
        Random random = new Random();
        for (int i = 0; i< 40; i++) {
            if (i == 0) {
                int j = random.nextInt(16);
                while (j==0) {
                    j = random.nextInt(16);
                }
                sb.append(ScaleTrans.byteToChar((byte) j));
                i++;
            }
            sb.append(ScaleTrans.byteToChar((byte) random.nextInt(16)));
        }
        return sb.toString();
    }

    /**
     *
     * @return
     */
    public static String createDeviceType() {
        Random random = new Random();
        String [] deviceType = {"iPhone7,2"};
        return deviceType[random.nextInt(deviceType.length)];
    }

    /**
     *
     * @return
     */
    public static String createScreenWidth() {
        Random random = new Random();
        String [] deviceType = {"750"};
        return deviceType[random.nextInt(deviceType.length)];
    }


    /**
     *
     * @return 090be04d-475c-40ab-a229-f02f4b02214d
     */
    public static String createIdfaAndVendorId() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString().toUpperCase();
    }

    public static String createMccMnc() {
        return "46000";
    }

    public static String createAccess() {
        return "WIFI";
    }



    public static void main(String[] args) {
        for (int i=0;i <1000; i++) {

            System.out.println(createOpenudid());
        }
    }
}
