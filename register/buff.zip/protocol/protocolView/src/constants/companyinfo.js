export const COMPANY_UPDATE = 'COMPANY_UPDATE';
export const COMPANY_RM = 'COMPANY_RM';
