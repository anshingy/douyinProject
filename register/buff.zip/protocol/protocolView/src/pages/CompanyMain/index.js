import CompanyMain from './CompanyMain';
export default CompanyMain;
