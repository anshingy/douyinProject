import LogoutButton from './LogoutButton';

export default LogoutButton;
