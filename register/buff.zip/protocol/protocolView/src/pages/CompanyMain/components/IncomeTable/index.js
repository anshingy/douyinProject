import IncomeTable from './IncomeTable';

export default IncomeTable;
