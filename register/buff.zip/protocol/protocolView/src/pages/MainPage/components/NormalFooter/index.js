import NormalFooter from './NormalFooter';

export default NormalFooter;
