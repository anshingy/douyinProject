import NameBar from './NameBar';

export default NameBar;
