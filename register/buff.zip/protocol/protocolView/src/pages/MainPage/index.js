import MainPage from './MainPage';
export default MainPage;
