import Company from './Company';
export default Company;
