import TextSearchList from './TextSearchList';

export default TextSearchList;
