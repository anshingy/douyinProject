import ArticleList from './ArticleList';

export default ArticleList;
