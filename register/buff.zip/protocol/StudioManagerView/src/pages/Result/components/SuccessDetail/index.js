import SuccessDetail from './SuccessDetail';

export default SuccessDetail;
