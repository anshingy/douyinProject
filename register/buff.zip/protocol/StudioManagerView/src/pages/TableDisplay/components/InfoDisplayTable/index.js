import InfoDisplayTable from './InfoDisplayTable';

export default InfoDisplayTable;
