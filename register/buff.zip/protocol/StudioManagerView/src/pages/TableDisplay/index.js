import TableDisplay from './TableDisplay';

export default TableDisplay;
