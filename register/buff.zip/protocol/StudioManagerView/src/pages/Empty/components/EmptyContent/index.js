import EmptyContent from './EmptyContent';

export default EmptyContent;
