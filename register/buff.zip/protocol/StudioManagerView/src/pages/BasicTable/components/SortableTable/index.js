import SortableTable from './SortableTable';

export default SortableTable;
