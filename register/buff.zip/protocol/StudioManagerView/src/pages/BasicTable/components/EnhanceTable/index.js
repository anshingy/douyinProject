import EnhanceTable from './EnhanceTable';

export default EnhanceTable;
