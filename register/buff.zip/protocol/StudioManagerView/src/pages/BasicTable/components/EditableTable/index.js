import EditableTable from './EditableTable';

export default EditableTable;
