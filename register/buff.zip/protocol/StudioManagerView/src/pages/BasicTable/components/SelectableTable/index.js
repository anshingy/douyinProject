import SelectableTable from './SelectableTable';

export default SelectableTable;
