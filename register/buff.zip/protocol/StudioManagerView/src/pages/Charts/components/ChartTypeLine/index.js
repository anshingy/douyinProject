import ChartTypeLine from './ChartTypeLine';

export default ChartTypeLine;
