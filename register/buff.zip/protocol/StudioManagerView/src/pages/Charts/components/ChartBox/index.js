import ChartBox from './ChartBox';

export default ChartBox;
