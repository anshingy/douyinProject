import ChartArea from './ChartArea';

export default ChartArea;
