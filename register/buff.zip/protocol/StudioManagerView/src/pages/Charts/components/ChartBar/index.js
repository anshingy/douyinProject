import ChartBar from './ChartBar';

export default ChartBar;
