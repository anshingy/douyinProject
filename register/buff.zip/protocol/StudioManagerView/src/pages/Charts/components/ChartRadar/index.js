import ChartRadar from './ChartRadar';

export default ChartRadar;
