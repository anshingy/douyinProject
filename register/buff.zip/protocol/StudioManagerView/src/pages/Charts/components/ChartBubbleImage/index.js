import ChartBubbleImage from './ChartBubbleImage';

export default ChartBubbleImage;
