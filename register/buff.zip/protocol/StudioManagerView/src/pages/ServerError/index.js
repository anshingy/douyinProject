import ServerError from './ServerError';

export default ServerError;
