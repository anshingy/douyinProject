import Portlets from './Portlets';

export default Portlets;
