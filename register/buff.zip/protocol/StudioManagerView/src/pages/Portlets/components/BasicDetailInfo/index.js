import BasicDetailInfo from './BasicDetailInfo';

export default BasicDetailInfo;
