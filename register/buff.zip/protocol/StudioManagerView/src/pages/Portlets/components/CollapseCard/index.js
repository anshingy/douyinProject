import CollapseCard from './CollapseCard';

export default CollapseCard;
