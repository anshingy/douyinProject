import DetailTable from './DetailTable';

export default DetailTable;
