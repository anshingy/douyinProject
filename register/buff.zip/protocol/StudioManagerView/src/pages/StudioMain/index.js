import StudioMain from './StudioMain';

export default StudioMain;
