import Fail from './Fail';

export default Fail;
