import FailureDetail from './FailureDetail';

export default FailureDetail;
