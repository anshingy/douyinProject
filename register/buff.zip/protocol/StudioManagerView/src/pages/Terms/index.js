import Terms from './Terms';

export default Terms;
