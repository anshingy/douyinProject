import NotPermission from './NotPermission';

export default NotPermission;
