import DisplayCard from './DisplayCard';

export default DisplayCard;
