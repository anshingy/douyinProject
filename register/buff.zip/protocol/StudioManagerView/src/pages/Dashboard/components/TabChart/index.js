import TabChart from './TabChart';

export default TabChart;
