import ProgressTable from './ProgressTable';

export default ProgressTable;
