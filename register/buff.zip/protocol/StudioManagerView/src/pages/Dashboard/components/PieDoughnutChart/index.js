import PieDoughnutChart from './PieDoughnutChart';

export default PieDoughnutChart;
