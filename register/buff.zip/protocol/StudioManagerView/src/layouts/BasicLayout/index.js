import BasicLayout from './BasicLayout';

export default BasicLayout;
