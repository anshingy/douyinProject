/*
 *
 * userLogout constants
 *
 */

export const USER_LOGOUT_REQUEST = 'PRO/USER_LOGOUT_REQUEST';
export const USER_LOGOUT_FAILURE = 'PRO/USER_LOGOUT_FAILURE';
export const USER_LOGOUT_SUCCESS = 'PRO/USER_LOGOUT_SUCCESS';
