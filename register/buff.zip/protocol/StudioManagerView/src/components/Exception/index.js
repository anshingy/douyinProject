import Exception from './Exception';

export default Exception;
